package com.bbb;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	String count = "(63)";
    	count = count.trim();
		count = count.substring(1, count.length() -1);
		System.out.println(count);
    }
}
