package com.bbb.mobile_SAN;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import com.bbb.AbstractTestCases;
import com.bbb.repository.OR;
import com.bbb.util.ExcelTestDataUtil;
import com.bbb.util.Utils;
import com.relevantcodes.extentreports.LogStatus;

public class USA_Sanity extends AbstractTestCases {

	// ********************************************************************************************************************************
	/*
	 * Method Title: tc_homepage Method Description: This Methods validates the
	 * header links DISPLAYED on the home page. Author: Vandhana.S
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_homepage() throws InterruptedException {

		// Validating the header of the homepage
		if (Utils.isElementFound(OR.BBBHeader)) {
			extest.log(LogStatus.PASS, "'HomePage Header' is DISPLAYED on the screen for the user to select.");
		}
		// Validating on the options visible on the header.
		if (Utils.isElementFound(OR.Menu) && (Utils.isElementFound(OR.Search) && (Utils.isElementFound(OR.BBBLogo)
				&& (Utils.isElementFound(OR.Registry) && (Utils.isElementFound(OR.Cart))))))
			;
		extest.log(LogStatus.PASS,
				"Options for 'Menu','Search','BedBath&Beyond','Registry','Cart' are DISPLAYED on the home screen for the user to select."
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));

		// Validating on the Menu options
		Utils.clickelement(OR.Menu);
		Utils.sleep(1000);
		extest.log(LogStatus.INFO, "User clicked on the Menu option to check for the available shopping streams"
				+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		Utils.sleep(1000);

		// final String menuoptionsDB1 = testMethodData.get("Menuoptions");
		if (Utils.isElementFound(OR.Holiday)) {
			extest.log(LogStatus.PASS, "Menu option 'HOLIDAY' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.Gifts)) {
			extest.log(LogStatus.PASS, "Menu option 'GIFTS' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.PersonalizedGifts)) {
			extest.log(LogStatus.PASS, "Menu option 'PERSONALIZED GIFTS' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.Bedding)) {
			extest.log(LogStatus.PASS, "Menu option 'BEDDING' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.Bath)) {
			extest.log(LogStatus.PASS, "Menu option 'BATH' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.Kitchen)) {
			extest.log(LogStatus.PASS, "Menu option 'KITCHEN' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.Dining)) {
			extest.log(LogStatus.PASS, "Menu option 'DINING' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.HomeDecor)) {
			extest.log(LogStatus.PASS, "Menu option 'HOME DECOR' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.Furniture)) {
			extest.log(LogStatus.PASS, "Menu option 'FURNITURE' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.StorageCleaning)) {
			extest.log(LogStatus.PASS, "Menu option 'STORAGE & CLEANING' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.Outdoor)) {
			extest.log(LogStatus.PASS, "Menu option 'OUTDOOR' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.BabyKids)) {
			extest.log(LogStatus.PASS, "Menu option 'BABY & KIDS' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.HealthBeauty)) {
			extest.log(LogStatus.PASS, "Menu option 'HEALTH & BEAUTY' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.More)) {
			extest.log(LogStatus.PASS, "Menu option 'MORE' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.Shops)) {
			extest.log(LogStatus.PASS, "Menu option 'SHOPS' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.HomeImprovement)) {
			extest.log(LogStatus.PASS, "Menu option 'HOME IMPROVEMENT' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.GiftCards)) {
			extest.log(LogStatus.PASS, "Menu option 'GIFT CARDS' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.TrackOrder)) {
			extest.log(LogStatus.PASS, "Menu option 'TRACK ORDER' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.FindaStoreMenu)) {
			extest.log(LogStatus.PASS, "Menu option 'FIND A STORE' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.MyOffers)) {
			extest.log(LogStatus.PASS, "Menu option 'MY OFFERS' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.MyaccountMenu)) {
			extest.log(LogStatus.PASS, "Menu option 'MY ACCOUNT' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.IdeaBoards)) {
			extest.log(LogStatus.PASS, "Menu option 'IDEA BOARDS' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.Mover)) {
			extest.log(LogStatus.PASS, "Menu option 'MOVER' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.TrendsIdeas)) {
			extest.log(LogStatus.PASS, "Menu option 'TRENDS & IDEAS' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.WeddingGiftRegistry)) {
			extest.log(LogStatus.PASS, "Menu option 'WEDDING & GIFT REGISTRY' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.College)) {
			extest.log(LogStatus.PASS, "Menu option 'COLLEGE' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.OtherWaystoShop)) {
			extest.log(LogStatus.PASS, "Menu option 'OTHER WAYS TO SHOP' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.CustomerSupport)) {
			extest.log(LogStatus.PASS, "Menu option 'CUSTOMER SUPPORT' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.ToTheTrade)) {
			extest.log(LogStatus.PASS, "Menu option 'To The Trade' option is DISPLAYED on the Homepage");
		}
		if (Utils.isElementFound(OR.DesktopSite)) {
			extest.log(LogStatus.PASS, "Menu option 'DESKTOP SITE' option is DISPLAYED on the Homepage");
		}

		Utils.clickelement(OR.Menu);
		if (driver.findElement(OR.Search).isEnabled()) {
			extest.log(LogStatus.PASS,
					"'Search' option is ENABLED on the Homepage for the user to search the desired item");
		} else {
			extest.log(LogStatus.ERROR,
					"'Search' option is NOT ENABLED on the Homepage for the user to search the desired item");
		}
		if (driver.findElement(OR.BBBLogo).isEnabled()) {
			extest.log(LogStatus.PASS,
					"'Bed Bath & Beyond Logo' is DISPLAYED on the Homepage for the user to return to the homepage of the site anytime needed");
		} else {
			extest.log(LogStatus.ERROR,
					"'Bed Bath & Beyond Logo' is NOT DISPLAYED on the Homepage for the user to return to the homepage of the site anytime needed");
		}
		if (driver.findElement(OR.Registry).isEnabled()) {
			extest.log(LogStatus.PASS,
					"'Registry' is DISPLAYED on the Homepage for the user to be navigated to the Registry options");
		} else {
			extest.log(LogStatus.ERROR,
					"'Registry' is NOT DISPLAYED on the Homepage for the user to be navigated to the Registry options");
		}
		if (driver.findElement(OR.Cart).isEnabled()) {
			extest.log(LogStatus.PASS,
					"'Cart' is DISPLAYED on the Homepage for the user to check the No.Of products added");
		} else {
			extest.log(LogStatus.ERROR,
					"'Cart' is NOT DISPLAYED on the Homepage for the user to check the No.Of products added");
		}
		Utils.scrolldown();
		if (Utils.isElementFound(OR.FindAStore)) {
			extest.log(LogStatus.PASS,
					"'Find A Store' is DISPLAYED on the Homepage for the user to check for the available near by stores");
		} else {
			extest.log(LogStatus.ERROR,
					"'Find A Store' is NOT DISPLAYED on the Homepage for the user to check for the available near by stores");
		}
		if (Utils.isElementFound(OR.GiftRegistry)) {
			extest.log(LogStatus.PASS,
					"'Gift Registry' is DISPLAYED on the Homepage for the user to check for the available near by stores"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR,
					"'Gift Registry' is NOT DISPLAYED on the Homepage for the user to check for the available near by stores"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		Utils.scrolldown(1400);
		Utils.sleep(1000);
		// Validating the Social annex(upload photo or Visit Gallery on home page)
		if (Utils.isElementFound(OR.SocialAnnex)) {
			Utils.clickelement(OR.SocialAnnex);
		}
		Utils.sleep(2000);
		if (Utils.isElementFound(OR.SocialUpload)) {
			extest.log(LogStatus.PASS,
					"'Upload Photo / Visit Gallery' is DISPLAYED on the screen for the user to select the media to upload the pictures."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL,
					"'Upload Photo / Visit Gallery' is NOT DISPLAYED on the screen for the user to select the media to upload the pictures."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.clickelement(OR.UploadWdwClose);

	}

	// ******************************************************************************************************************************
	/*
	 * Method Title: tc_ropis; Method Description: This Method validates on the buy
	 * online and pick up instore items. Author: Vandhana.S
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_ropis() {

		// Searching the item to validate on the ropis
		WebElement searchFormInput = driver.findElement(OR.SearchInput);
		String searchitem = testMethodData.get("SKU");
		searchFormInput.sendKeys(searchitem);
		extest.log(LogStatus.INFO, "Entering the SKU '" + searchitem + "'to validate the Truck Develivery option");

		Utils.enter(OR.SearchInput);
		Utils.waitForLoad(driver);
		WebElement searchresult = driver.findElement(OR.ProductName);
		String uiresults = searchresult.getAttribute("title");
		if (searchresult.isDisplayed()) {
			extest.log(LogStatus.PASS, " " + uiresults + " is DISPLAYED as result of the searched item"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, " " + uiresults + " is NOT DISPLAYED as result of the searched item"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Selecting the store to reserve the item
		Utils.clickelement(OR.ChangeStore);
		Utils.sleep(2000);
		String ZipCode = testMethodData.get("ZipCode");
		Utils.entertext(OR.EnterZip, ZipCode);
		Utils.sleep(1000);
		Utils.clickelement(OR.FindStore);
		Utils.sleep(1000);
		if (Utils.isElementFound(OR.SelectStore)) {
			extest.log(LogStatus.PASS, "List of stores are DISPLAYED and the User selects the first available store"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "List of stores are  NOT DISPLAYED as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.clickelement(OR.SelectStore);
		Utils.sleep(2000);
		Utils.clickelement(OR.ProductName);
		extest.addScreenCapture(Utils.captureScreenShot(driver));
		Utils.sleep(3000);
		Utils.scrolldown(200);
		if ((driver.findElement(OR.ReserveNow)).isDisplayed()) {
			extest.log(LogStatus.PASS,
					"'Reserve Now' button is DISPLAYED to reserve the product online and pick up in store."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.clickelement(OR.ReserveNow);
		if (Utils.isElementFound(OR.Addedtocart)
				&& (Utils.isElementFound(OR.CheckOut) && (Utils.isElementFound(OR.ViewCart)))) {
			extest.log(LogStatus.PASS,
					"'Added to cart' message is DISPLAYED along with the 'CHECK OUT' and 'VIEW CART' options "
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else if (Utils.isElementFound(By.xpath("//*[@id='dialoghead']"))) {
			extest.log(LogStatus.ERROR,
					"ropis functionality is turned off" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		if (Utils.isElementFound(OR.AddedtoURCart)
				&& (Utils.isElementFound(OR.KeepShopping) && (Utils.isElementFound(OR.ViewCart)))) {
			extest.log(LogStatus.PASS,
					"'Added to your cart' message is DISPLAYED along with the 'VIEW CART' and 'KEEP SHOPPING' options "
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else if (Utils.isElementFound(By.xpath("//*[@id='dialoghead']"))) {
			extest.log(LogStatus.ERROR,
					"ropis functionality is turned off" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

	}
	// *******************************************************************************************************************

	// *******************************************************************************************************************
	/*
	 * Method Title: tc_newAcctandIdeaBoard Method Description: This Method
	 * validates on the new account creation and the options available for the user.
	 * Author: Vandhana.S
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_newAcctandIdeaBoard() {

		// Clicking on the SignIn/Account to Initiate the new account process.
		Utils.clickelement(OR.Menu);
		Utils.sleep(1000);
		Utils.clickelement(OR.SignIn);
		Utils.sleep(2000);
		// Creating the New Account for the User.
		String UserEmail = Utils.random();
		// Insert the UserName to the excel sheet
		Utils.entertext(OR.NewEmailID, UserEmail);
		Utils.clickelement(OR.CreateAcctBtnPg1);
		Utils.sleep(1000);
		String UserFirstName = testMethodData.get("UFirstName");
		String UserLastname = testMethodData.get("ULastname");
		String Pswd = testMethodData.get("Password");
		Utils.entertext(OR.FirstName, UserFirstName);
		Utils.entertext(OR.LastName, UserLastname);
		Utils.entertext(OR.NewPswd, Pswd);
		Utils.entertext(OR.NewCnfrmPswd, Pswd);
		extest.log(LogStatus.INFO,
				"'Details with - User Email: " + UserEmail + ", First Name: " + UserFirstName + ", Last Name: "
						+ UserLastname + " and Password: " + Pswd + " have been entered to create an account.");

		String rowNum = testMethodData.get("rowNum");
		String sheetName = testMethodData.get("sheetName");
		ExcelTestDataUtil.setCellData(Integer.valueOf(rowNum) + 2, 4, sheetName, UserEmail);

		extest.addScreenCapture(Utils.captureScreenShot(driver));
		Utils.clickelement(OR.CreateAcctBtnPg2);

		// Validating UserName is DISPLAYED on the right top corner near the heart icon.
		String UIUserName = driver.findElement(OR.UserName).getText();
		if (UIUserName.contains(UserFirstName)) {
			extest.log(LogStatus.PASS, "User First Name '" + UserFirstName + "' is DISPLAYED as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "User Name is NOT DISPLAYED as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating the User is able to see the My Account OverView.
		if (driver.findElement(OR.MyAccount).isDisplayed()) {
			extest.log(LogStatus.PASS, "User is been directed to the 'My Account' Page"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.PASS, "User cannot see the Options for the My Account screen "
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Validating if the User is able to see all the options related to 'My Account.
		String myaccountoptions = testMethodData.get("MyAccountOptions");

		List<WebElement> allOptions = driver.findElements(By.xpath("//*[@id='myAccount']/div[5]/div/ul/li/a"));
		int allOptionsCount = allOptions.size();

		// Validating the Expected and UI options are same.
		for (int i = 0; i < allOptionsCount; i++) {
			String optionValue = allOptions.get(i).getText();
			if (myaccountoptions.contains(optionValue)) {
				extest.log(LogStatus.PASS,
						"My Account Option -> " + "'" + optionValue + "'" + " is DISPLAYED as expected");
			} else {
				extest.log(LogStatus.ERROR,
						"My Account Option -> " + "'" + optionValue + "'" + " is NOT DISPLAYED as expected");
			}
		}
		extest.addScreenCapture(Utils.captureScreenShot(driver));

		Utils.sleep(1000);
		String ideaboardname1 = testMethodData.get("IdeaBoard1");
		String ideaboardname2 = testMethodData.get("IdeaBoard2");
		String searchItem1 = testMethodData.get("SearchItem1");
		String addNotes = testMethodData.get("AddNotes");
		Utils.clickelement(OR.Search);
		Utils.entertext((OR.SearchInput), searchItem1);
		extest.log(LogStatus.INFO,
				"Entering the search item for " + searchItem1 + " to start the Idea Board validation");
		Utils.enter(OR.SearchInput);
		Utils.sleep(2000);
		Utils.clickelement(OR.List);
		Utils.sleep(2000);
		List<WebElement> heart = driver.findElements(OR.IBcertona);
		Utils.sleep(1000);
		heart.get(1).click();
		Utils.sleep(2000);
		// Creating Idea board one
		Utils.clickelement(OR.UserCreateIB);
		Utils.sleep(2000);
		Utils.entertext(OR.NewBoardName, ideaboardname1);
		Utils.sleep(1000);
		Utils.enter(OR.NewBoardName);
		Utils.sleep(4000);
		heart = driver.findElements(OR.IBcertona);
		heart.get(2).click();
		Utils.sleep(3000);
		WebElement addtoIB1 = driver.findElement(By.xpath("//a[contains(text(),'" + ideaboardname1 + "')]"));
		if (addtoIB1.isDisplayed()) {
			extest.log(LogStatus.PASS, "The IdeaBoard " + ideaboardname1 + " has been CREATED"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "The IdeaBoard " + ideaboardname1 + " is NOT CREATED"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(2000);
		Utils.clickelement(OR.Back);
		Utils.sleep(2000);
		heart = driver.findElements(OR.IBcertona);
		heart.get(2).click();
		Utils.sleep(2000);
		addtoIB1 = driver.findElement(By.xpath("//a[contains(text(),'" + ideaboardname1 + "')]"));
		addtoIB1.click();
		Utils.sleep(4000);
		heart = driver.findElements(OR.IBcertona);
		heart.get(3).click();
		Utils.sleep(2000);
		// Creating Idea Board 2
		Utils.clickelement(OR.UserCreateIB);
		Utils.sleep(1000);
		Utils.entertext(OR.NewBoardName, ideaboardname2);
		Utils.sleep(1000);
		Utils.enter(OR.NewBoardName);
		Utils.sleep(4000);
		heart = driver.findElements(OR.IBcertona);
		heart.get(4).click();
		WebElement addtoIB2 = driver.findElement(By.xpath("//a[contains(text(),'" + ideaboardname2 + "')]"));
		if (addtoIB2.isDisplayed()) {
			extest.log(LogStatus.PASS,
					"The second IdeaBoard " + ideaboardname2
							+ " has been CREATED and the item is added to the Idea Board"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL,
					"The second IdeaBoard " + ideaboardname2 + " is NOT CREATED to add the item to Idea Board"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		addtoIB2 = driver.findElement(By.xpath("//a[contains(text(),'" + ideaboardname2 + "')]"));
		addtoIB2.click();
		Utils.sleep(4000);
		Utils.scrollup();
		Utils.clickelement(OR.Menu);
		Utils.sleep(2000);
		Utils.scrolldown();
		Utils.clickelement(OR.IdeaBoards);
		// if this does not work change the code

		Utils.sleep(2000);
		WebElement userIB = driver.findElement(By.xpath("//*[contains(text(),'" + ideaboardname1 + "')]"));
		userIB.click();
		Utils.sleep(2000);
		Utils.clickelement(OR.IBListView);
		Utils.sleep(2000);
		// Adding notes to the product
		List<WebElement> addnotes = driver.findElements(By.xpath("//div[contains(text(),'Add Note')]"));
		addnotes.get(1).click();
		Utils.sleep(3000);
		Utils.entertext(OR.AddNotes, addNotes);
		Utils.sleep(1000);
		List<WebElement> SaveIB = driver.findElements(OR.SaveNote);
		for (int i = 0; i <= SaveIB.size(); i++) {
			try {
				if (SaveIB.get(i).isEnabled()) {
					Utils.clickelement(OR.SaveNote);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		Utils.sleep(4000);
		WebElement addNotetitle = driver.findElement(By.xpath("//div[contains(text(),'" + addNotes + "')]"));
		if (addNotetitle.isDisplayed()) {
			extest.log(LogStatus.PASS, "Notes with " + ideaboardname2 + " has been UPDATED to the Idea Board"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "Notes with " + ideaboardname2 + " has NOT been UPDATED to the Idea Board"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Moving the products to another idea board
		Utils.sleep(2000);
		List<WebElement> ibOptions = driver.findElements(By.xpath("//*[@class='ib_moreLink fr']"));
		ibOptions.get(1).click();
		List<WebElement> ibMove = driver.findElements(By.xpath("//*[@class='MoveModal']"));
		ibMove.get(1).click();
		WebElement movetoIB = driver.findElement(By.xpath("//*[@data-ideaboardname='" + ideaboardname2 + "']"));
		if (movetoIB.isDisplayed()) {
			movetoIB.click();
			Utils.sleep(3000);
			extest.log(LogStatus.PASS, "The item has been MOVED to the " + ideaboardname2 + " Idea Board"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "The item has NOT been MOVED to the " + ideaboardname2 + " Idea Board"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(2000);
		Utils.scrollup();
		Utils.clickelement(By.xpath("//*[@class='editIBName']"));
		Utils.sleep(2000);
		String edittitle = Utils.randomtext();
		driver.findElement(By.xpath("(//*[@id='boardName'])[2]")).clear();
		Utils.entertext(By.xpath("(//*[@id='boardName'])[2]"), edittitle);
		extest.log(LogStatus.PASS, "Idea Board name has been EDITED to " + edittitle + ""
				+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		Utils.sleep(2000);
		Utils.enter(By.xpath("(//*[@id='boardName'])[2]"));
		Utils.sleep(4000);
		Utils.clickelement(OR.Menu);
		Utils.sleep(1000);
		Utils.clickelement(OR.IdeaBoards);
		Utils.sleep(2000);

		if (driver.findElement(By.xpath("//*[@class='boardTitleText'][contains(text(),'" + edittitle + "')]"))
				.isEnabled()) {
			Utils.sleep(2000);
			List<WebElement> selectIB = driver.findElements(By.xpath("//*[@class='ib_moreLink fr']"));
			Utils.sleep(1000);
			selectIB.get(1).click();
			List<WebElement> deleteIB = driver.findElements(By.xpath("//*[@class='deleteModal']"));
			Utils.sleep(1000);
			deleteIB.get(1).click();
			List<WebElement> confrmdel = driver
					.findElements(By.xpath("//*[@class='ibButtonPrimary confimDeleteBoard']"));
			Utils.sleep(1000);
			confrmdel.get(1).click();
			extest.log(LogStatus.PASS, "The IdeaBoard " + ideaboardname2 + "was DELETED"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "The IdeaBoard " + ideaboardname2 + "was NOT DELETED"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

	}

	// *******************************************************************************************************************************
	/*
	 * Method Title: tc_PLP_PDP_SingleSKU; Method Description: This Method validates
	 * on search option to validate the user is able to see the search related
	 * items. Author: Vandhana.S
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_L1L2_SingleSKU() {

		// Getting the no of PLP and PDPs to be validated.
		// int noOfPLPPDPs =
		// Double.valueOf(testMethodData.get("NoOfPLPPDPs")).intValue();

		driver.findElement(OR.Menu).click();
		Utils.sleep(1000);
		driver.findElement(By.xpath("(//*[@id='leftNavMenu']/nav/ul/li/a[contains(text(),'Bedding')])[2]")).click();
		Utils.sleep(1000);
		extest.log(LogStatus.INFO,
				"Navigation of L1-->L2, Menu--> Bedding" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		driver.findElement(By.xpath("(//*[@id='leftNavMenu']/nav[1]/ul/li[3]/div/div/ul/li[2]/a)[2]")).click();
		Utils.sleep(1000);
		extest.log(LogStatus.INFO,
				"Navigation of L2-->L3, Bedding to Bedding" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		driver.findElement(By.xpath("(//*[@id='leftNavMenu']/nav[1]/ul/li[3]/div/div/ul/li[2]/div/div/ul/li[2]/a)[2]"))
				.click();
		Utils.sleep(1000);
		WebElement l3title = driver.findElement(By.xpath("//*[@id='1-1']/div/div[2]/h2/a"));
		String l3itemtitle = l3title.getText();
		l3title.click();
		extest.log(LogStatus.INFO, "Navigation of L3-->PDP, Bedding to Comfroter Sets"
				+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		Utils.sleep(1000);
		WebElement l4title = driver.findElement(By.xpath("//*[@id='productHeader']/div[3]/h1/div"));
		String l4itemtitle = l4title.getText();
		if (l3itemtitle.equalsIgnoreCase(l4itemtitle)) {
			extest.log(LogStatus.PASS, "Navigation of L1-->L2-->L3 to PDP hasbeen successful"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else if (l3itemtitle.contains(l4itemtitle)) {
			extest.log(LogStatus.PASS, "Navigation of L1-->L2-->L3 to PDP hasbeen successful"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.scrolldown();
		// Validating on the ATC & ATR and Find a Store & Quantity & validating if there
		// is any collection for the collection items
		if (driver.findElement(By.xpath("//*[@id='secondaryIBButton']/a")).isEnabled()) {
			if (driver.findElement(By.xpath("//*[@id=\"skuSizeSelector\"]")).isDisplayed()) {
				extest.log(LogStatus.PASS, "'Size selection' is DISPLAYED as expected");
			}
			if (driver.findElement(By.xpath("//*[@id='OrderondrolWidget']/div[2]/div/div[1]/div[4]/div[2]/button/span"))
					.isDisplayed()) {
				extest.log(LogStatus.PASS, "'Find a Store' is DISPLAYED as expected");
			} else if (driver
					.findElement(By.xpath("//*[@id='OrderondrolWidget']/div[2]/div/div[1]/div[4]/div[2]/button/span"))
					.isDisplayed()) {
				extest.log(LogStatus.PASS, "'Find More Stores' is DISPLAYED as expected");
			} else if (driver
					.findElement(By.xpath("//*[@id='OrderondrolWidget']/div[2]/div/div[1]/div[4]/div[2]/button/span"))
					.isDisplayed()) {
				extest.log(LogStatus.PASS, "'View More Store' is DISPLAYED as expected");
			}
			if ((Utils.isElementFound(OR.PDPQuantity)) && ((Utils.isElementFound(OR.PDPATC))
					&& ((Utils.isElementFound(OR.PDPATR) && ((Utils.isElementFound(OR.PDPIdeaBoard))))))) {
				extest.log(LogStatus.PASS,
						"'Add to Cart','Add to Registry','Quantity','IdeaBoard' is DISPLAYED as expected"
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			} else {
				extest.log(LogStatus.ERROR,
						"'Add to Cart','Add to Registry','Quantity','IdeaBoard' is NOT DISPLAYED as expected"
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
		} else if (driver.findElement(By.xpath("//*[@id='1-1']/div/div[2]/h2/a")).isDisplayed()) {
			driver.findElement(By.xpath("//*[@id='1-1']/div/div[2]/h2/a")).click();
			Utils.sleep(1000);
			Utils.scrolldown();
			driver.findElement(
					By.xpath("//*[@id='productList']/div/ul/li[1]/section/div/div/div/div[1]/div[1]/div[2]/h3/a"))
					.click();
			Utils.sleep(1000);
			Utils.scrolldown(350);
			if (driver.findElement(By.xpath("//*[@id=\"skuSizeSelector\"]")).isDisplayed()) {
				extest.log(LogStatus.PASS, "'Size selection' is DISPLAYED as expected");
			}
			if (driver.findElement(By.xpath("//*[@id='OrderondrolWidget']/div[2]/div/div[1]/div[4]/div[2]/button/span"))
					.isDisplayed()) {
				extest.log(LogStatus.PASS, "'Find a Store' is DISPLAYED as expected");
			} else if (driver
					.findElement(By.xpath("//*[@id='OrderondrolWidget']/div[2]/div/div[1]/div[4]/div[2]/button/span"))
					.isDisplayed()) {
				extest.log(LogStatus.PASS, "'Find More Stores' is DISPLAYED as expected");
			} else if (driver
					.findElement(By.xpath("//*[@id='OrderondrolWidget']/div[2]/div/div[1]/div[4]/div[2]/button/span"))
					.isDisplayed()) {
				extest.log(LogStatus.PASS, "'View More Store' is DISPLAYED as expected");
			}
			if ((Utils.isElementFound(OR.PDPQuantity)) && ((Utils.isElementFound(OR.PDPATC))
					&& ((Utils.isElementFound(OR.PDPATR) && ((Utils.isElementFound(OR.PDPIdeaBoard))))))) {
				extest.log(LogStatus.PASS,
						"'Add to Cart','Add to Registry','Quantity','IdeaBoard' is DISPLAYED as expected"
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			} else {
				extest.log(LogStatus.ERROR,
						"'Add to Cart','Add to Registry','Quantity','IdeaBoard' is NOT DISPLAYED as expected"
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
		}
		Utils.scrollup();
		/*
		 * if(Utils.isElementFound(OR.Menu)) { Utils.clickelement(OR.Menu); }
		 * 
		 * for(int j=5;j>=1;j--) {
		 * if(Utils.isElementFound(By.xpath("(//*[@id='leftNavHeader']/div["+ j
		 * +"]/a)[2]"))) {
		 * 
		 * Utils.clickelement(By.xpath("(//*[@id='leftNavHeader']/div["+ j +"]/a)[2]"));
		 * } } if(Utils.isElementFound(By.xpath("(//*[@class='lev1 mainLevel'])[2]"))){
		 * Utils.clickelement(OR.Menu); }
		 */
	}

	// *******************************************************************************************************************************
	/*
	 * Method Title: tc_PLP_PDP_MultiSKU; Method Description: This Method validates
	 * on search option to validate the user is able to see the search related
	 * items. Author: Vandhana.S
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_L1L2_Coll_MultiSKU() {

		driver.findElement(OR.Menu).click();
		Utils.sleep(1000);
		driver.findElement(By.xpath("(//*[@id='leftNavMenu']/nav/ul/li/a[contains(text(),'Bath')])[2]")).click();
		Utils.sleep(1000);
		extest.log(LogStatus.INFO,
				"Navigation of L1-->L2, Menu--> Bath" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		driver.findElement(By.xpath("(//a[contains(text(),'Bath Towels & Rugs')])[3]")).click();
		Utils.sleep(1000);
		extest.log(LogStatus.INFO, "Navigation of L2-->L3, Bath--> Bath Towels & Rugs"
				+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		driver.findElement(By.xpath("(//a[contains(text(),'Bath Towels')])[8]")).click();
		Utils.sleep(1000);
		WebElement l3title = driver.findElement(By.xpath("//*[@id='1-1']/div/div[2]/h2/a"));
		String l3itemtitle = l3title.getText();
		l3title.click();
		extest.log(LogStatus.INFO, "Navigation of L3-->PDP" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		Utils.sleep(1000);
		WebElement l4title = driver.findElement(By.xpath("//*[@id='productHeader']/div[3]/h1/div"));
		String l4itemtitle = l4title.getText();
		if (l3itemtitle.equalsIgnoreCase(l4itemtitle)) {
			extest.log(LogStatus.PASS, "Navigation of L1-->L2-->L3 to PDP hasbeen successful"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else if (l3itemtitle.contains(l4itemtitle)) {
			extest.log(LogStatus.ERROR, "Navigation of L1-->L2-->L3 to PDP was NOT successful"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.scrolldown(1100);

		if (Utils.isElementFound(By.xpath("(//*[@class='productDetails span12 marTop_10']/h3)[1]"))) {
			extest.log(LogStatus.PASS, "'Product Collection' is DISPLAYED as expected");
			driver.findElement(By.xpath("(//*[@class='productDetails span12 marTop_10']/h3)[1]")).click();
			Utils.sleep(1000);
			Utils.scrolldown();
			if (Utils.isElementFound(By.xpath("//*[@id='skuColorSelector']/div/div/div[1]/div[1]"))) {
				Utils.clickelement((By.xpath("//*[@id='skuColorSelector']/div/div/div[1]/div[1]")));
				extest.log(LogStatus.PASS, "'Color selection' is DISPLAYED as expected");
			}
			Utils.sleep(1000);
			Utils.scrolldown(350);
			if (Utils.isElementFound(By.xpath("//*[@id='skuSizeSelector']"))) {
				extest.log(LogStatus.PASS, "'Size selection' is DISPLAYED as expected");
			}
			if (driver.findElement(By.xpath("//span[contains(text(),'Find In Store')]")).isDisplayed()) {
				extest.log(LogStatus.PASS, "'Find a Store' is DISPLAYED as expected");
			} else if (driver.findElement(By.xpath("//span[contains(text(),'Find More Stores')]")).isDisplayed()) {
				extest.log(LogStatus.PASS, "'Find More Stores' is DISPLAYED as expected");
			} else if (driver.findElement(By.xpath("//span[contains(text(),'View All Stores')]")).isDisplayed()) {
				extest.log(LogStatus.PASS, "'View All Stores' is DISPLAYED as expected");
			}
			if (Utils.isElementFound(By.xpath("//*[@id='skuColorSelector']/div/div/div[1]/div[1]"))) {
				Utils.clickelement((By.xpath("//*[@id='skuColorSelector']/div/div/div[1]/div[1]")));
				extest.log(LogStatus.PASS, "'Color selection' is DISPLAYED as expected");
			}
			if ((Utils.isElementFound(OR.PDPQuantity)) && ((Utils.isElementFound(OR.PDPATC))
					&& ((Utils.isElementFound(OR.PDPATR) && ((Utils.isElementFound(OR.PDPIdeaBoard))))))) {
				extest.log(LogStatus.PASS,
						"'Add to Cart','Add to Registry','Quantity','IdeaBoard' is DISPLAYED as expected"
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			} else {
				extest.log(LogStatus.ERROR,
						"'Add to Cart','Add to Registry','Quantity','IdeaBoard' is NOT DISPLAYED as expected"
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
		}
		Utils.scrollup();

	}

	// *******************************************************************************************************************************
	/*
	 * Method Title: tc_sortFilter; Method Description: This Method validates on
	 * sort and filter options as well as the bread crumb. Author: Vandhana.S
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_sortFilter() {
		// Clicking on the Kitchen L1 and Navigating to PLP screen to validations
		driver.findElement(OR.Menu).click();
		extest.log(LogStatus.PASS,
				"Navigation of Menu--> L1, Menu--> Home Decor" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		Utils.sleep(1000);
		driver.findElement(By.xpath("(//*[@id='leftNavMenu']/nav/ul/li/ul/li/a[contains(text(),'Home Decor')])[2]")).click();
		Utils.sleep(1000);
		extest.log(LogStatus.PASS,
				"Navigation of L1-->L2, Home Decor" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		driver.findElement(By.xpath("(//a[contains(text(),'Clocks')])[9]")).click();
		Utils.sleep(1000);
		extest.log(LogStatus.PASS, "Navigation of L2-->L3, Home Decor --> Clocks"
				+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		driver.findElement(By.xpath("(//a[contains(text(),'Shop All Clocks')])[2]")).click();
		Utils.sleep(2000);
		if (Utils.isElementFound(By.xpath("//*[@id='bcContainer']/ul"))) {
			extest.log(LogStatus.PASS,
					"Bread Crumb for 'Home / Home Decor / Clocks' is DISPLAYED as per the user search flow"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		if(Utils.isElementFound(By.xpath("//div[@class='prodListContainer list']"))){
			extest.log(LogStatus.PASS,	"Items are displayed in the List View");
		}
			
		Utils.clickelement(OR.GridView);
		Utils.sleep(2000);
		if(Utils.isElementFound(By.xpath("//div[@class='prodListContainer grid']"))){
			extest.log(LogStatus.PASS,	"Items are displayed in the GRID View");
		}
				
		Utils.clickelement(OR.Sort);
		if(Utils.isElementFound(By.xpath("//*[@class='sortAndFilter']"))) {
		extest.log(LogStatus.INFO," Sort by Options are visible to the user to select the desired sort option"	+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.clickelement(By.xpath("//span[text()='Price - low to high']"));
		Utils.sleep(2000);
		WebElement resultcunt = driver.findElement(By.xpath("//span[@class='matchingCount']"));
		String resultCount = resultcunt.getText();
		resultcunt.click();
		Utils.sleep(2000);
		WebElement displycunt = driver.findElement(By.xpath("//*[@id='searchKeywords']/span"));
		String displyedcount = displycunt.getText();
		resultCount = resultCount.replace("(","");
		resultCount = resultCount.replace(")","");
		resultCount = resultCount.replace(" ","");
		displyedcount = displyedcount.replace("(","");
		displyedcount = displyedcount.replace(")","");
		displyedcount = displyedcount.replace(" ","");
		if(resultCount.equals(displyedcount)) {
			extest.log(LogStatus.PASS,
					"Low to High price filter displayed results count is the SAME as the view results count "
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}else {
			extest.log(LogStatus.FAIL,
					"Low to High price filter displayed results count is NOT SAME as the view results count "
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		
		Utils.sleep(2000);
		List<WebElement> pricediff = driver.findElements(By.xpath("//*[@class='isPrice priceColor text-red']"));
		WebElement firstitemprice = pricediff.get(0);
		String itemprice1 = firstitemprice.getText();
		itemprice1 = itemprice1.replace("$", "");
		itemprice1 = itemprice1.replace(" ", "");
		itemprice1 = itemprice1.replace(",", "");
		itemprice1 = itemprice1.replace("Each", "");
		WebElement seconditemprice = pricediff.get(1);
		String itemprice2 = seconditemprice.getText();
		itemprice2 = itemprice2.replace("$", "");
		itemprice2 = itemprice2.replace(" ", "");
		itemprice2 = itemprice2.replace(",", "");
		itemprice2 = itemprice2.replace("Each", "");
		double ip1 = 0;
		double ip2 = 0;
		if (itemprice1.contains("-")) {
			String[] itemprice1Array = itemprice1.split("-");
			String price1 = itemprice1Array[0];

			ip1 = Double.valueOf(price1);
		} else {
			ip1 = Double.valueOf(itemprice1);
		}
		if (itemprice2.contains("-")) {
			String[] itemprice2Array = itemprice2.split("-");
			String price2 = itemprice2Array[0];
			price2.replace("$", "");
			ip2 = Double.valueOf(price2);

		} else {
			ip2 = Double.valueOf(itemprice2);
		}
		// comparing the first and second price of the products
		if (ip1 <= ip2) {

			extest.log(LogStatus.PASS, "First item price'" + ip1 + "' is LOWER than Second item price'" + ip2 + "'"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "First item price'" + ip1 + "' is NOT LOWER than Second item price '" + ip2
					+ "'" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		
		Utils.clickelement(OR.Sort);
		if(Utils.isElementFound(By.xpath("//*[@class='sortAndFilter']"))) {
		extest.log(LogStatus.INFO," Sort by Options are visible to the user to select the desired sort option"	+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.clickelement(By.xpath("//span[text()='Price - high to low ']"));
		Utils.sleep(2000);
		WebElement resultcunth = driver.findElement(By.xpath("//span[@class='matchingCount']"));
		String resultCounth = resultcunth.getText();
		resultcunth.click();
		Utils.sleep(2000);
		WebElement displycunth = driver.findElement(By.xpath("//*[@id='searchKeywords']/span"));
		String displyedcounth = displycunth.getText();
		resultCounth = resultCounth.replace("(","");
		resultCounth = resultCounth.replace(")","");
		resultCounth = resultCounth.replace(" ","");
		displyedcounth = displyedcounth.replace("(","");
		displyedcounth = displyedcounth.replace(")","");
		displyedcounth = displyedcounth.replace(" ","");
		if(resultCounth.equals(displyedcounth)) {
			extest.log(LogStatus.PASS,
					"High to Low price filter displayed results count is the SAME as the view results count "
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}else {
			extest.log(LogStatus.FAIL,
					"High to Low price filter displayed results count is NOT SAME as the view results count "
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}		
		Utils.sleep(2000);
		List<WebElement> pricediffs = driver.findElements(By.xpath("//*[@class='isPrice priceColor text-red']"));
		WebElement firstIprice = pricediffs.get(0);
		String itemPrice3 = firstIprice.getText();
		itemPrice3 = itemPrice3.replace("$", "");
		itemPrice3 = itemPrice3.replace(" ", "");
		itemPrice3 = itemPrice3.replace(",", "");
		itemPrice3 = itemPrice3.replace("Each", "");
		WebElement secondIprice = pricediffs.get(1);
		String itemPrice4 = secondIprice.getText();
		itemPrice4 = itemPrice4.replace("$", "");
		itemPrice4 = itemPrice4.replace(" ", "");
		itemPrice4 = itemPrice4.replace(",", "");
		itemPrice4 = itemPrice4.replace("Each", "");

		double ip3 = 0;
		double ip4 = 0;
		System.out.println(itemPrice3);
		if (itemPrice3.contains("-")) {
			String[] itemprice1Array = itemPrice3.split("-");
			String price3 = itemprice1Array[0];

			ip3 = Double.valueOf(price3);
		} else {
			ip3 = Double.valueOf(itemPrice3);
		}
		if (itemPrice4.contains("-")) {
			String[] itemprice2Array = itemPrice4.split("-");
			String price4 = itemprice2Array[0];
			price4.replace("$", "");
			ip4 = Double.valueOf(price4);

		} else {
			ip4 = Double.valueOf(itemPrice4);
		}
		// comparing the first and second price of the products
		if (ip3 >= ip4) {

			extest.log(LogStatus.PASS, "First item price'" + ip3 + "' is HIGHER or Equal to Second item price'" + ip4
					+ "'" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "First item price'" + ip3 + "' is NOT HIGHER than Second item price '" + ip4
					+ "'" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
	}

	// *******************************************************************************************************************************
	/*
	 * Method Title: tc_LTL_Assembly; Method Description: This Method validates on
	 * Truck delivery, Assembly options. Author: Vandhana.S
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_LTL_Assembly() {

		// Validating the Truck Load
		
	//	Utils.clickelement(OR.Search);
		String searchitem = testMethodData.get("SearchItem");
		if(Utils.isElementFound(OR.SearchInput)){
			Utils.entertext((OR.SearchInput), searchitem);
		}else {
			Utils.clickelement(OR.Search);
			Utils.sleep(1000);
			Utils.entertext((OR.SearchInput), searchitem);			
		}		
		Utils.enter(OR.SearchInput);		
		extest.log(LogStatus.INFO,
				"Entering the SKU '" + searchitem + "' to validate the Truck Develivery option");
		WebElement searchresult = driver.findElement(OR.ProductName);
		String uiresults = searchresult.getAttribute("title");
		if (searchresult.isDisplayed()) {
			extest.log(LogStatus.PASS, " " + uiresults + " is DISPLAYED as result of the searched item"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, " " + uiresults + " is NOT DISPLAYED as result of the searched item"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(3000);
		searchresult.click();
		Utils.waitForLoad(driver);
		WebElement truckdelopt = driver.findElement(OR.TruckDeliveryOption);
		if (truckdelopt.isDisplayed()) {
			extest.log(LogStatus.PASS, "Truck delivery option is VISIBLE for the searched item"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "Truck delivery option is NOT VISIBLE for the searched item"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		WebElement selectdeloption = driver.findElement(OR.SelectDelOption);
		selectdeloption.click();
		Utils.sleep(1000);
		String deliveryoption = testMethodData.get("DeliveryOption");
		Utils.clickelement(By.xpath("//*[contains(text(),'" + deliveryoption + "')]"));
		Utils.sleep(1000);
		Utils.scrolldown();
		WebElement slctporch = driver.findElement(OR.SelectPorch);
		if (Utils.isElementFound(OR.SelectPorch)) {
			slctporch.click();
			extest.log(LogStatus.PASS, "Assembly option is VISIBLE for the searched item"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "Assembly option is NOT VISIBLE for the searched item"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(2000);
		String porchzipcode = testMethodData.get("ZipCode");
		if (Utils.isElementFound(OR.PorchZipcode)) {
			Utils.sleep(1000);
			Utils.entertext(OR.PorchZipcode, porchzipcode);
			driver.findElement(OR.PorchZipcode).clear();
			Utils.sleep(1000);
			Utils.entertext(OR.PorchZipcode, porchzipcode);
			Utils.sleep(1000);
			WebElement noOfPieces = driver.findElement(By.xpath("//label[@for='radio-0']/div"));
			String estprice = noOfPieces.getText();
			driver.findElement(By.xpath("//label[@for='radio-0']")).click();
			extest.log(LogStatus.INFO, "Available installation charges are DISPLAYED "
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			Utils.clickelement(By.xpath("//*[@class='porchButton']"));
			Utils.sleep(2000);
			WebElement estpdppriceis = driver.findElement(By.xpath("//*[@class='serviceAttachWidget-checkbox-label']//span"));
			String estpdpprice = estpdppriceis.getText();
			if (estpdpprice.contains(estprice)) {
				extest.log(LogStatus.PASS, "Assembly charges are DISPLAYED as SELECTED"
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			} else {
				extest.log(LogStatus.FAIL, "Assembly charges are NOT DISPLAYED as SELECTED "
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
		}
		Utils.scrollup();
		Utils.clickelement(OR.AddtoCart);
		Utils.sleep(1000);
		if (Utils.isElementFound(OR.CartSummary)) {
			extest.log(LogStatus.PASS,
					"Cart Summary is DISPLAYED as expected" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			Utils.isElementFound(OR.Cart);
			Utils.clickelement(OR.Cart);
			Utils.sleep(2000);
			if ((driver.findElement(By.xpath("//*[@id='cartMain']//h6/a")).isDisplayed())) {
				extest.log(LogStatus.PASS, "Cart Summary is DISPLAYED as expected"
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			} else {
				extest.log(LogStatus.FAIL, "Cart Summary is DISPLAYED as expected"
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
		}
	}

	// *******************************************************************************************************************************
	/*
	 * Method Title: tc_shopbyBrand; Method Description: This Method validates on
	 * the comparison of the products. Author: Vandhana.S
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_shopbyBrand() {

		// Selecting the products to shop by Brand
		Utils.clickelement(OR.Menu);
		Utils.sleep(1000);
		Utils.clickelement(OR.WaystoBrand);
		extest.log(LogStatus.INFO,
				"Selecting 'Shop by Brand'" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		Utils.clickelement(OR.ShopbyBrand);
		Utils.sleep(3000);
		if (Utils.isElementFound(OR.BrandsPage) && (Utils.isElementFound(OR.FeaturedBrands)&& (Utils.isElementFound(OR.SearchBrand)))) {
			extest.log(LogStatus.PASS,
					"Page with list of Brands is DISPLAYED" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "Page with list of Brands is NOT DISPLAYED"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Selecting the brand letter to validate on the list of brands displayed for
		// that selection.
		Utils.sleep(2000);
		String brandlettersel = testMethodData.get("BrandL");
		WebElement brandletter = driver.findElement(By.xpath("//*[@href='#" + brandlettersel + "']"));
		brandletter.click();
		Utils.sleep(2000);
		String selectBrand = testMethodData.get("DesiredBrand");
		extest.log(LogStatus.INFO, "Desired Brand name is '" + selectBrand + "'");
		WebElement uiBrand = driver.findElement(By.xpath("//*[@data-value='" + selectBrand + "']/a"));
		if (uiBrand.isDisplayed()) {
			extest.log(LogStatus.PASS, "Brand is DISPLAYED as per the user selection"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "Brand is NOT DISPLAYED as per the user selection"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		uiBrand.click();
		Utils.sleep(2000);
		List<WebElement> products = driver.findElements(By.xpath("(//div[@class='productSummary']/h2/a)"));
		for (int i = 0; i <=2; i++) {
			WebElement productname = products.get(i);
			String productTitle = productname.getText();
			productTitle = productTitle.toLowerCase();
			selectBrand = selectBrand.toLowerCase();
			if (productTitle.contains(selectBrand)) {
				extest.log(LogStatus.PASS,
						"Displayed product name '" + productTitle + "' is the same as the DESIRED Brand name"
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			} else {
				extest.log(LogStatus.FAIL, "Brand is NOT DISPLAYED as per the user selection"
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
			Utils.scrolldown();
			Utils.sleep(1000);
		}

	}

}
