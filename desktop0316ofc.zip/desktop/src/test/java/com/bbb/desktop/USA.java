package com.bbb.desktop;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import com.bbb.AbstractTestCases;
import com.bbb.repository.OR;
import com.bbb.util.ExcelTestDataUtil;
import com.bbb.util.Utils;
import com.relevantcodes.extentreports.LogStatus;

public class USA extends AbstractTestCases {
	// ********************************************************************************************************************************
	/**
	 * Method Title: tc_homepage Method Description: This Methods validates the
	 * header links DISPLAYED on the home page. Author: Vandhana.S Date: 02/26/2018
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_homepage() throws InterruptedException {

		// Validating the Hero Image box--> Image cannot be validated, we are checking
		// if the banner is present.
		WebElement heroBanner = driver.findElement(OR.HeroBanner);
		if (Utils.isElementFound(OR.HeroBanner) && heroBanner.isDisplayed()) {
			extest.log(LogStatus.PASS, "'Hero Image and Banner' is DISPLAYED on the home page.");
		} else {
			extest.log(LogStatus.ERROR, "Hero Image and Banner' is NOT DISPLAYED on the home page."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Validating the Sister links visibility.
		String sisterlinks = testMethodData.get("SisterLinks");

		List<WebElement> allOptions = driver.findElements(OR.UISisterLinks);
		int allOptionsCount = allOptions.size();

		// Validating the Expected and UI options are same.
		for (int i = 0; i < allOptionsCount; i++) {
			String sisterlink = allOptions.get(i).getAttribute("title");
			if (sisterlinks.contains(sisterlink)) {
				extest.log(LogStatus.PASS, "Sister Link --> " + "'" + sisterlink + "'" + " is DISPLAYED as expected");
			} else {
				extest.log(LogStatus.ERROR,
						"Sister Link --> " + "'" + sisterlink + "'" + " is NOT DISPLAYED as expected");
			}
		}
		extest.addScreenCapture(Utils.captureScreenShot(driver));

		// Validating the Social annex(upload photo or Visit Gallery on home page)

		if (Utils.isElementFound(OR.SocialAnnex)) {
			Utils.clickelement(OR.SocialAnnex);
			Utils.sleep(1000);
			if (Utils.isElementFound(OR.SocialUpload)) {
				extest.log(LogStatus.PASS,
						"'Upload Photo / Visit Gallery' is DISPLAYED on the screen for the user to select the media to upload the pictures."
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			} else {
				extest.log(LogStatus.ERROR,
						"'Upload Photo / Visit Gallery' is NOT DISPLAYED on the screen for the user to select the media to upload the pictures."
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
			Utils.clickelement(OR.UploadWdwClose);
		}
		Utils.sleep(1000);
		Utils.scrollup();
		Utils.scrollup();

		// Validating the visual registry from promo box.

		// Utils.scrollToElement(OR.GiftPromoRgsrty);
		String UserFirstName = testMethodData.get("UFirstName");
		String UserLastname = testMethodData.get("ULastname");
		if (Utils.isElementFound(OR.GiftRegFirstN)) {
			Utils.entertext(OR.GiftRegFirstN, UserFirstName);
			if (Utils.isElementFound(OR.GiftRegLastN)) {
				Utils.entertext(OR.GiftRegFirstN, UserLastname);
			}
			Utils.clickelement(OR.SearchGRHomePg);
			Utils.sleep(1000);
		}
		if (Utils.isElementFound(OR.GiftRegistriesPg)) {
			extest.log(LogStatus.PASS,
					"'Gift Registries' screen DISPLAYED after giving the registry details in the promo box."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR,
					"'Gift Registries' screen is NOT DISPLAYED after giving the registry details in the promo box."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Validating the Trends & Ideas tab
		// Utils.scrollup();
		if (Utils.isElementFound(OR.TrendsNIdeas)) {
			WebElement trendsideas = driver.findElement(OR.TrendsNIdeas);
			trendsideas.click();
			Actions action = new Actions(driver);
			action.moveToElement(driver.findElement(OR.TrendsIdeasmerch)).perform();
			Utils.waitForLoad(driver);
			extest.log(LogStatus.PASS,
					"'Trends & Ideas' Merch template is visible when mouse is hovered on to the 'Trends & Ideas'"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR,
					"'Trends & Ideas' Merch template is NOT visible when mouse is hovered on to the 'Trends & Ideas'"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		Utils.clickelement(OR.BBBLink);
		Utils.waitForLoad(driver);
		Utils.scrolldown();
		// Validating the save to Idea Board from the Certona Container
		List<WebElement> heart = driver.findElements(OR.IBcertona);
		heart.get(3).click();
		Utils.waitForLoad(driver);
		Utils.clickelement(OR.CreateIB);
		Utils.sleep(2000);
		String autoIBName = testMethodData.get("IdeaBoardName");
		Utils.entertext(OR.IBName, autoIBName);
		Utils.clickelement(OR.SaveIB);
		Utils.sleep(4000);
		heart.get(2).click();

		WebElement ibgivenTitle = driver.findElement(By.xpath("//*[@class='iBNameText']"));
		String ibTitle = ibgivenTitle.getText();
		if (ibTitle.equalsIgnoreCase(autoIBName)) {
			extest.log(LogStatus.PASS,
					"'Idea Board' is been created and the Title " + autoIBName
							+ " is DISPLAYED as given for the Title of Idea Board ."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR,
					"'Idea Board' is been created and the Title " + autoIBName
							+ " is NOT DISPLAYED as given for the Title of Idea Board ."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		Utils.clickelement(By.xpath("//*[@class='ui-icon ui-icon-closethick']"));
		Utils.scrollup();
		// Validating the College and Registry Tabs.
		if (Utils.isElementFound(By.id("shopForCollegeLink"))) {
			extest.log(LogStatus.PASS, "'College' Tab is visible on the Home Page as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "'College' Tab is NOT visible on the Home Page which is not expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		if (Utils.isElementFound(By.id("bridalGiftRegistryLink"))) {
			extest.log(LogStatus.PASS, "'Gift Registry' Tab is visible on the Home Page as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "'Gift Registry' Tab is NOT visible on the Home Page which is not expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		if (Utils.isElementFound(OR.Search)) {
			extest.log(LogStatus.PASS, "'Search Option' Tab is visible on the Home Page as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "'Search Option' Tab is NOT visible on the Home Page which is not expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Validating the Sign In Icon
		if (Utils.isElementFound(OR.SignIn)) {
			extest.log(LogStatus.PASS, "'Sign In/Account Icon' has been DISPLAYED as expected."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "'Sign In/Account Icon' is DISPLAYED as expected."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating the Heart Icon
		if (Utils.isElementFound(OR.Heart)) {
			Utils.clickelement(OR.Heart);
			Utils.waitForLoad(driver);
			if (Utils.isElementFound(OR.CreateIdeaBoard)) {
				extest.log(LogStatus.PASS,
						"'Heart Icon' has been DISPLAYED as expected and is navigated to the Ideaboard home page after clicking on it."
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			} else {
				extest.log(LogStatus.ERROR,
						"'Heart Icon' is NOT DISPLAYED or is NOT navigated to the IdeaBoard homepage which is not expected"
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
		}
		// Validating the Cart Icon
		if (Utils.isElementFound(OR.Cart)) {
			extest.log(LogStatus.PASS, "'Cart Icon' has been DISPLAYED as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "'Cart con' is NOT DISPLAYED which is not expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating 'Find a Store' Link
		driver.findElement(OR.FindAStore).click();
		Utils.waitForLoad(driver);
		WebElement storelocator = driver.findElement(OR.StoreLocator);
		if (storelocator.isDisplayed()) {
			extest.log(LogStatus.PASS,
					"'Find A Store' Link has been SUCCESSFULLY directed to the Store Locator screen to enter the Location Details"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR,
					"'Find A Store' Link was NOT directed to the Store Locator screen to enter the Location Details as expected"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating 'You May Like' Link
		driver.findElement(OR.YouMayLike).click();
		Utils.waitForLoad(driver);
		WebElement recommendations = driver.findElement(OR.OurRecommendations);
		if (recommendations.isDisplayed()) {
			extest.log(LogStatus.PASS,
					"'You May Like' Link has been SUCCESSFULLY directed to the 'Our Recommendations' screen with the suggestions."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR,
					"'You May Like' Link was NOT directed to the 'Our Recommendations' screen suggestions as expected."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		/*
		 * // Validating 'Sign Up For Offers' Link WebElement SignUpForOffers =
		 * driver.findElement(OR.SignUpForOffers); WebElement MyOffers =
		 * driver.findElement(OR.MyOffers); if (SignUpForOffers.isDisplayed()) {
		 * extest.log(LogStatus.PASS,
		 * "'Sign Up For Offers' Link has been SUCCESSFULLY DISPLAYED on the screen.");
		 * }else if (MyOffers.isDisplayed()) { extest.log(LogStatus.PASS,
		 * "'Sign Up For Offers' Link has been SUCCESSFULLY DISPLAYED on the screen.");
		 * } Utils.waitForLoad(driver);
		 */
		// Validating 'Track Order' Link
		driver.findElement(OR.TrackOrder).click();
		Utils.waitForLoad(driver);
		WebElement OrderTracking = driver.findElement(OR.OrderTracking);
		if (OrderTracking.isDisplayed()) {
			extest.log(LogStatus.PASS,
					"'Track Order' Link has been SUCCESSFULLY directed to the 'Order Tracking' screen."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "'Track Order' Link was NOT directed to the 'Track Order' screen as expected."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating the 'Contact US' Link
		/*
		 * driver.findElement(OR.ContactUS).click(); Utils.sleep(3000);
		 * Utils.waitForLoad(driver); WebElement ContactUspage =
		 * driver.findElement(OR.ContactUsPage); if (ContactUspage.isDisplayed()) {
		 * extest.log(LogStatus.PASS,
		 * "'Contact US' Link has been SUCCESSFULLY directed to the 'Contact US' screen."
		 * ); extest.addScreenCapture(Utils.captureScreenShot(driver)); } else {
		 * extest.log(LogStatus.ERROR,
		 * "'Contact US' Link was NOT directed to the 'Contact US' screen as expected."
		 * ); extest.addScreenCapture(Utils.captureScreenShot(driver)); }
		 */
		// Validating the link is DISPLAYED Gift Cards
		WebElement giftcards = driver.findElement(OR.GiftCards);
		if (giftcards.isDisplayed()) {
			extest.log(LogStatus.PASS, "'Gift Cards' Link is DISPLAYED on the home page.");
		} else {
			extest.log(LogStatus.ERROR, "Gift Cards' Link is NOT DISPLAYED on the home page."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Validating the International Shipping

		Utils.clickelement(OR.ShipTo);
		Utils.sleep(2000);
		if (Utils.isElementFound(OR.Internationalshppng)) {
			if ((Utils.isElementFound(OR.SelectCountry))) {
				extest.log(LogStatus.PASS, "Select Country is DISPLAYED to select the desired Country."
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			} else {
				extest.log(LogStatus.ERROR, "Select Country is NOT DISPLAYED to select the desired Country"
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
			if ((Utils.isElementFound(OR.SelectCurrency))) {
				extest.log(LogStatus.PASS, "Select Currency is DISPLAYED to select the desired Country."
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			} else {
				extest.log(LogStatus.ERROR, "Select Currency is NOT DISPLAYED to select the desired Country"
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
		}
		if (Utils.isElementFound(OR.Clsmodal)) {
			Utils.clickelement(OR.Clsmodal);
			Utils.sleep(3000);
			Utils.waitForLoad(driver);
		}

		Utils.clickelement(OR.BBBLink);
		Utils.sleep(3000);
		Utils.scrolldown();

	}

	// *******************************************************************************************************************
	/**
	 * Method Title: tc_accountcreation Method Description: This Method validates on
	 * the new account creation and the options available for the user. Author:
	 * Vandhana.S Date: 02/27/2018
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_accountcreation() {

		// Clicking on the SignIn/Account to Initiate the new account process.
		Utils.clickelement(OR.SignIn);
		// Creating the New Account for the User.
		String UserEmail = Utils.random();
		// Insert the UserName to the excel sheet
		Utils.entertext(OR.NewEmailID, UserEmail);
		Utils.clickelement(OR.CreateNewAcctPg1);
		Utils.sleep(1000);

		String UserFirstName = testMethodData.get("UFirstName");
		String UserLastname = testMethodData.get("ULastname");
		String Pswd = testMethodData.get("Password");
		String Invalidpswd = testMethodData.get("InvalidPassword");
		Utils.entertext(OR.FirstName, UserFirstName);
		Utils.entertext(OR.LastName, UserLastname);
		Utils.entertext(OR.NewPswd, Invalidpswd);
		Utils.sleep(1000);
		extest.log(LogStatus.INFO, "Error Msg for 'Password Requirement' is displayed to enter the valid password. "
				+ extest.addScreenCapture(Utils.captureScreenShot(driver)));

		driver.findElement(OR.NewPswd).clear();
		Utils.sleep(1000);
		Utils.scrolldown();
		Utils.entertext(OR.NewPswd, Pswd);
		Utils.entertext(OR.NewCnfrmPswd, Pswd);
		extest.log(LogStatus.PASS,
				"'Details with - User Email: " + UserEmail + ", First Name: " + UserFirstName + ", Last Name: "
						+ UserLastname + " and Password: " + Pswd + " have been entered to create an account.");

		String rowNum = testMethodData.get("rowNum");
		String sheetName = testMethodData.get("sheetName");
		ExcelTestDataUtil.setCellData(Integer.valueOf(rowNum) + 2, 4, sheetName, UserEmail);

		extest.addScreenCapture(Utils.captureScreenShot(driver));
		Utils.clickelement(OR.CreateNewAcctPg2);

		// Validating the Congratulations message after the User account is created.

		if (driver.findElement(OR.CongratsMsg).isDisplayed()) {
			extest.log(LogStatus.PASS, "Congratulations! Your account has now been created."
					+ "Message is DISPLAYED as expected" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR,
					"Congratulations! Your account has now been created." + "Message is NOT DISPLAYED as expected"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating UserName is DISPLAYED on the right top corner near the heart icon.
		String UIUserName = driver.findElement(OR.UserName).getText();
		if (UIUserName.contains(UserFirstName)) {
			extest.log(LogStatus.PASS, "User First Name '" + UserFirstName + "' is DISPLAYED as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "User Name is NOT DISPLAYED as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating the User is able to see the My Account OverView.
		if (driver.findElement(OR.MyAccountVal).isDisplayed()) {
			extest.log(LogStatus.PASS, "User is been directed to the 'My Account' Page"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.PASS, "User cannot see the Options for the My Account screen "
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Validating if the User is able to see all the options related to 'My Account.
		String myaccountoptions = testMethodData.get("MyAccountOptions");

		List<WebElement> allOptions = driver.findElements(By.xpath("//*[@id='content']/div[2]/div/ul/li"));
		int allOptionsCount = allOptions.size();

		// Validating the Expected and UI options are same.
		for (int i = 0; i < allOptionsCount; i++) {
			String optionValue = allOptions.get(i).getText();
			if (myaccountoptions.contains(optionValue)) {
				extest.log(LogStatus.PASS,
						"My Account Option -> " + "'" + optionValue + "'" + " is DISPLAYED as expected");
			} else {
				extest.log(LogStatus.ERROR,
						"My Account Option -> " + "'" + optionValue + "'" + " is NOT DISPLAYED as expected");
			}
		}
		extest.addScreenCapture(Utils.captureScreenShot(driver));

		// Logging Out of the application.
		Utils.clickelement(OR.LogOutMyAccount);
		Utils.sleep(2000);
		if ((Utils.isElementFound(OR.SignIn))) {
			extest.log(LogStatus.PASS, "User Logged out of the Application Succesfully"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "User could NOT Log Out of the Application Succesfully"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
	}

	// *******************************************************************************************************************************
	/**
	 * Method Title --> tc_quickview ; Method Description--> This Method validates
	 * on QUICK VIEW and related options available. Author: Vandhana.S Date:
	 * 02/27/2018
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_quickview() {

		// Searching for a specific item

		String userID = testMethodData.get("UserID");
		String passWord = testMethodData.get("Password");
		Utils.login(userID, passWord);
		WebElement searchFormInput = driver.findElement(OR.InputsearchItem);
		String searchitem1 = testMethodData.get("SearchItem_1");
		searchFormInput.sendKeys(searchitem1);
		extest.log(LogStatus.INFO,
				"Entering the item '" + searchitem1 + "'to check the result, DISPLAYED as per the search");

		WebElement searchButton = driver.findElement(OR.SearchItem);
		searchButton.click();
		Utils.waitForLoad(driver);
		;
		WebElement searchresult = driver.findElement(OR.ProductName);
		String uiresults = searchresult.getAttribute("title");
		if (searchitem1.equals(uiresults)) {
			extest.log(LogStatus.PASS, "The DISPLAYED item '" + uiresults + "'is the same as the search item '"
					+ searchitem1 + "'." + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "The DISPLAYED item '" + uiresults + "'is NOT the same as the search item '"
					+ searchitem1 + "'." + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Validating the quick view access
		Utils.clickelement(By.xpath("//*[contains(text(),'Quick View')]"));
		Utils.waitForLoad(driver);
		WebElement qvTitle = driver.findElement(By.xpath("//*[@id='productTitle']/a"));
		String qvDisplayedTitle = qvTitle.getText();
		if (searchitem1.equals(qvDisplayedTitle)) {
			extest.log(LogStatus.PASS,
					"The DISPLAYED item on Quick View'" + uiresults + "'is the same as the search item '" + searchitem1
							+ "'." + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL,
					"The DISPLAYED item on Quick View '" + uiresults + "'is NOT the same as the search item '"
							+ searchitem1 + "'." + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		if (driver.findElement(By.xpath("//*[@class='prodDescHead noMar']")) != null) {
			extest.log(LogStatus.PASS, "'PRODUCT DESCRIPTION' is DISPLAYED on the quick view page.");
		}

		if (driver.findElement(By.xpath("//*[@id='quantity']")) != null) {
			extest.log(LogStatus.PASS, "'QUANTITY' selection is DISPLAYED on the quick view page.");
		}
		if (driver.findElement(By.xpath("//*[@value='Add To Registry']")) != null) {
			extest.log(LogStatus.PASS, "'ADD TO REGISTRY' is DISPLAYED on the quick view page.");
		}

		if (driver.findElement(By.xpath("//*[@name='btnAddToCart']")) != null) {
			Utils.clickelement(By.xpath("//*[@name='btnAddToCart']"));
			Utils.waitForLoad(driver);
			WebElement cart = driver.findElement(By.xpath("//*[@class='cartAddedTitle']"));
			String cartTitle = cart.getText();
			if (searchitem1.equals(cartTitle)) {
				extest.log(LogStatus.PASS,
						"'ADD TO CART' is DISPLAYED and User is navigated to the item cart summary, and the product title"
								+ cartTitle + " is the SAME as searched item."
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
			if (driver.findElement(By.xpath("//a[contains(text(),'VIEW CART')]")) != null) {
				extest.log(LogStatus.PASS, "'VIEW CART' is DISPLAYED on the quick modal page.");
			}
			if (driver.findElement(By.xpath("//input[@class='continueShop']")) != null) {
				driver.findElement(By.xpath("//input[@class='continueShop']")).click();
				Utils.sleep(2000);
				extest.log(LogStatus.PASS, "'KEEP SHOPPING' is DISPLAYED on the quick modal page.");
			}
			extest.log(LogStatus.PASS, "Quick View Modal page is DISPLAYED as expected ");
		} else {
			extest.log(LogStatus.FAIL, "Quick View Modal page is NOT DISPLAYED as expected ");
		}

		Utils.clickelement(By.xpath("//*[contains(text(),'Quick View')]"));
		Utils.waitForLoad(driver);
		Utils.clickelement(By.xpath("//*[@value='Add To Registry']"));
		Utils.waitForLoad(driver);
		WebElement registry = driver.findElement(By.xpath("//*[@class='registryAddedTitle']"));
		String registryTitle = registry.getText();
		if (searchitem1.equals(registryTitle)) {
			extest.log(LogStatus.PASS,
					"'Add to cart' is DISPLAYED and User is navigated to the item cart summary, and the product title"
							+ registryTitle + " is the SAME as searched item."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		if (driver.findElement(By.xpath("//input[@class='viewRegistry']")) != null) {
			extest.log(LogStatus.PASS, "'VIEW REGISTRY' is DISPLAYED on the quick modal page.");
		}
		if (driver.findElement(By.xpath("//a[contains(text(),'KEEP SHOPPING')]")) != null) {
			driver.findElement(By.xpath("//a[contains(text(),'KEEP SHOPPING')]")).click();
			Utils.sleep(2000);
			extest.log(LogStatus.PASS, "'KEEP SHOPPING' is DISPLAYED on the quick modal page.");
		}

		Utils.clickelement(By.xpath("//*[contains(text(),'Quick View')]"));
		Utils.waitForLoad(driver);
		if (Utils.isElementFound(By.xpath("//*[@id='saveToBoardLink']"))) {
			Utils.clickelement(By.xpath("//*[@id='saveToBoardLink']"));
			Utils.waitForLoad(driver);
			if (Utils.isElementFound(By.xpath("//a[@class='noline']"))) {
				extest.log(LogStatus.PASS,
						"'ADD TO IDEA BOARD' is DISPLAYED as expected and User is able to add the item to the Idea Board"
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
			Utils.sleep(4000);
			List<WebElement> closebtn = driver.findElements(OR.Clsmodal);
			for (int i = 0; i < closebtn.size(); i++) {
				if ((closebtn.get(i)).isDisplayed()) {
					(closebtn.get(i)).click();
				}
			}

		} else {
			extest.log(LogStatus.FAIL, "'Idea Board' is NOT DISPLAYED on the quick modal page as expected.");
		}

		Utils.clickelement(By.xpath("//*[contains(text(),'Quick View')]"));
		Utils.waitForLoad(driver);

		if (Utils.isElementFound(By.xpath("//*[contains(text(),'Find In Store')]"))) {
			Utils.clickelement(By.xpath("//*[contains(text(),'Find In Store')]"));
			if (Utils.isElementFound(By.xpath("//*[@id='txtStoreZip']"))
					&& (Utils.isElementFound(By.xpath("//*[@id='txtStoreAddress']")))
					&& (Utils.isElementFound(By.xpath("//*[@id='txtStoreCity']")))
					&& (Utils.isElementFound(By.xpath("//*[@id='txtStoreState']")))
					&& (Utils.isElementFound(By.xpath("//*[@id='selRadius']")))
					&& (Utils.isElementFound(By.xpath("//span[contains(text(),'Go')]")))
					&& (Utils.isElementFound(By.xpath("//span[contains(text(),'Cancel')]")))) {
				extest.log(LogStatus.PASS,
						"'FIND IN STORE' Modal page is DISPLAYED as expected and User can see the options for Zip code, Address, City, State and Radius"
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			} else {
				extest.log(LogStatus.FAIL,
						"'FIND IN STORE' Modal page is DISPLAYED as expected and User can see the options for Zip code, Address, City, State and Radius"
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
			Utils.clickelement(By.xpath("//span[contains(text(),'Cancel')]"));
		}

		List<WebElement> certona = driver.findElements(By.xpath("//*[@class='carousel clearfix']"));
		if (certona.listIterator() != null) {
			extest.log(LogStatus.PASS, "'CERTONA' container is DISPLAYED as expected on the Quick view modal"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "'CERTONA' container is DISPLAYED as expected on the Quick view modal"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

	}

	// ********************************************************************************************************************************
	/**
	 * Method Title: tc_ideaboard; Method Description: This Method validates on Idea
	 * Boards and the options available for the user. Author: Vandhana.S Date:
	 * 02/27/2018
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_ideaboard() throws InterruptedException

	{
		// Creating a new UserAccount to validate the IdeaBoard concept
		// Utils.tc_newUAccount();
		Utils.sleep(1000);
		String ideaboardname1 = testMethodData.get("IdeaBoard1");
		String ideaboardname2 = testMethodData.get("IdeaBoard2");
		String searchItem1 = testMethodData.get("SearchItem1");
		String addNotes = testMethodData.get("AddNotes");
		Utils.entertext((OR.Search), searchItem1);
		Utils.clickelement(OR.SearchItem);
		Utils.waitForLoad(driver);
		List<WebElement> heart = driver.findElements(OR.IBcertona);
		heart.get(0).click();
		Utils.sleep(2000);
		Utils.clickelement(OR.UserCreateIB);
		Utils.sleep(1000);
		Utils.entertext(OR.NewBoardName, ideaboardname1);
		Utils.clickelement(OR.SaveIB);
		Utils.sleep(4000);
		heart.get(0).click();
		Utils.sleep(2000);
		WebElement addtoIB1 = driver.findElement(By.xpath("//span[contains(text(),'" + ideaboardname1 + "')]"));
		if (addtoIB1.isDisplayed()) {
			extest.log(LogStatus.PASS, "The IdeaBoard " + ideaboardname1 + " has been CREATED"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.PASS, "The IdeaBoard " + ideaboardname1 + " is NOT CREATED"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(2000);
		Utils.popUpCls();
		heart.get(1).click();
		Utils.sleep(2000);
		addtoIB1 = driver.findElement(By.xpath("//span[contains(text(),'" + ideaboardname1 + "')]"));
		addtoIB1.click();
		Utils.sleep(4000);
		heart.get(2).click();
		Utils.sleep(2000);
		Utils.clickelement(OR.UserCreateIB);
		Utils.sleep(2000);
		Utils.entertext(OR.NewBoardName, ideaboardname2);
		Utils.clickelement(OR.SaveIB);
		Utils.sleep(4000);
		Utils.scrolldown();
		heart.get(3).click();
		WebElement addtoIB2 = driver.findElement(By.xpath("//span[contains(text(),'" + ideaboardname2 + "')]"));
		if (addtoIB2.isDisplayed()) {
			extest.log(LogStatus.PASS,
					"The second IdeaBoard " + ideaboardname2
							+ " has been CREATED and the item is added to the Idea Board"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.PASS,
					"The second IdeaBoard " + ideaboardname2 + " is NOT CREATED to add the item to Idea Board"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		addtoIB2 = driver.findElement(By.xpath("//span[contains(text(),'" + ideaboardname2 + "')]"));
		addtoIB2.click();
		Utils.sleep(4000);
		Utils.clickelement(OR.UserName);
		Utils.sleep(2000);
		if (driver.findElement(OR.UserIBMyAccount).isDisplayed()) {
			Utils.clickelement(OR.UserIBMyAccount);
		}
		Utils.sleep(2000);
		WebElement userIB = driver.findElement(By.xpath("//*[contains(text(),'" + ideaboardname1 + "')]"));
		userIB.click();
		Utils.sleep(2000);
		List<WebElement> addnotes = driver.findElements(By.xpath("//*[contains(text(),'Add Note')]"));
		addnotes.get(0).click();
		Utils.sleep(3000);
		Utils.entertext(OR.AddNotes, addNotes);
		Utils.sleep(1000);
		Utils.clickelement(OR.SaveNote);
		Utils.sleep(4000);
		WebElement addNotetitle = driver.findElement(By.xpath("//span[contains(text(),'" + addNotes + "')]"));
		if (addNotetitle.isDisplayed()) {
			extest.log(LogStatus.PASS, "Notes with " + ideaboardname2 + " has been UPDATED to the Idea Board"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "Notes with " + ideaboardname2 + " has NOT been UPDATED to the Idea Board"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(2000);
		List<WebElement> ibOptions = driver.findElements(By.xpath("//*[@class='ideaBoardMore_icon']"));
		ibOptions.get(0).click();
		List<WebElement> ibMove = driver.findElements(By.xpath("//*[@class='movetxt']"));
		ibMove.get(0).click();
		WebElement movetoIB = driver.findElement(By.xpath("//span[contains(text(),'" + ideaboardname2 + "')]"));
		if (movetoIB.isDisplayed()) {
			movetoIB.click();
			Utils.sleep(2000);
			extest.log(LogStatus.PASS, "The item has been MOVED to the " + ideaboardname2 + " Idea Board"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "The item has NOT been MOVED to the " + ideaboardname2 + " Idea Board"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(2000);
		Utils.clickelement(By.xpath("//a[contains(text(),'My Idea Boards')]"));
		ibOptions = driver.findElements(By.xpath("//*[@class='ideaBoardMore_icon']"));
		ibOptions.get(1).click();
		List<WebElement> delIBs = driver.findElements(By.xpath("//*[@class='deletetxt']"));
		delIBs.get(1);
		if ((delIBs.get(1)).isEnabled()) {
			delIBs.get(1).click();
			Utils.sleep(2000);
			List<WebElement> deleteIB = driver.findElements(By.xpath("//*[@id='deleteBoardBtn']"));
			deleteIB.get(1).click();
			extest.log(LogStatus.PASS, "The IdeaBoard " + ideaboardname2 + "was DELETED"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "The IdeaBoard " + ideaboardname2 + "was NOT DELETED"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		Utils.clickelement(OR.UserName);
		Utils.sleep(2000);
		Utils.logOut();

	}

	// *******************************************************************************************************************************
	/**
	 * Method Title: tc_PLP_PDP; Method Description: This Method validates on
	 * search option to validate the user is able to see the search related items.
	 * Author: Vandhana.S Date: 02/27/2018
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_PLP_PDP() {

		// Getting the no of PLP and PDPs to be validated.
		int noOfPLPPDPs = Double.valueOf(testMethodData.get("NoOfPLPPDPs")).intValue();

		for (int i = 4; i <= noOfPLPPDPs; i++) {

			Actions action = new Actions(driver);
			driver.findElement(OR.Products).click();
			Utils.sleep(1000);
			action.pause(2)
					.moveToElement(
							driver.findElement(By.xpath("//*[@id='collegeBridalArea']/div[1]/div/ul/li[" + i + "]/a")))
					.pause(1)
					.moveToElement(driver.findElement(By.xpath(
							"//*[@id='collegeBridalArea']/div[1]/div/ul/li[" + i + "]/div/div[1]/ul[1]/li[2]/a")))
					.pause(1).click().build().perform();

			Utils.waitForLoad(driver);

			if (Utils.isElementFound(By.xpath("//*[@id='row1']/div[1]"))) {
				extest.log(LogStatus.PASS, "First Row and Column is DISPLAYED AS EXPECTED");
			} else {
				extest.log(LogStatus.ERROR, "First Row and Column is NOT DISPLAYED AS EXPECTED");
			}

			if (Utils.isElementFound(By.xpath("//*[@id='row1']/div[2]"))) {
				extest.log(LogStatus.PASS, "Second Row and Column is DISPLAYED AS EXPECTED");
			} else {
				extest.log(LogStatus.ERROR, "Second Row and Column is NOT DISPLAYED AS EXPECTED");
			}

			if (Utils.isElementFound(By.xpath("//*[@id='row1']/div[3]"))) {
				extest.log(LogStatus.PASS, "Third Row and Column is DISPLAYED AS EXPECTED");
			} else {
				extest.log(LogStatus.ERROR, "Third Row and Column is NOT DISPLAYED AS EXPECTED");
			}

			String productTitle = "";
			if (Utils.isElementFound(By.xpath("//*[@id='row1']/div[1]/div[2]/div[3]/div[1]/a"))) {
				WebElement titleElement = driver.findElement(By.xpath("//*[@id='row1']/div[1]/div[2]/div[3]/div[1]/a"));
				productTitle = titleElement.getText();
				extest.log(LogStatus.INFO,
						"The item " + productTitle + "has been selected in PLP screen to be navigated to PDP screen"
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
				titleElement.click();
				Utils.waitForLoad(driver);

				WebElement proTitleElement = driver.findElement(By.xpath("//*[@id='productTitle']"));
				String displayedTitle = proTitleElement.getText();
				if (productTitle.equalsIgnoreCase(displayedTitle)) {
					extest.log(LogStatus.PASS,
							"The item displayed " + displayedTitle + " is the same as Selected in PLP screen."
									+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
				} else {
					extest.log(LogStatus.FAIL,
							"The item displayed " + displayedTitle + " is NOT the same as Selected in PLP screen."
									+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
				}

				By prodView = By.xpath("//*[@id='prodViewDefault-tab1']/a");
				// Utils.scrolldown(1600);
				Utils.scrolldown();
				if (Utils.isElementFound(prodView)) {
					extest.log(LogStatus.PASS, "'Product Information' is DISPLAYED as expected ");
				} else {
					extest.log(LogStatus.ERROR, "'Product Information' is NOT DISPLAYED as expected ");
				}

				By ratingView = By.xpath("//*[@id='prodViewDefault-tab2']/a");
				if (Utils.isElementFound(ratingView)) {
					extest.log(LogStatus.PASS, "'Ratings & Review' is DISPLAYED as expected ");
				} else {
					extest.log(LogStatus.ERROR, "'Ratings & Review' is NOT DISPLAYED as expected ");
				}

				By verifyView = By.xpath("//*[@id='prodViewDefault-tab3']/a");
				if (Utils.isElementFound(verifyView)) {
					extest.log(LogStatus.PASS, "'Ratings & Review' is DISPLAYED as expected ");
				} else {
					extest.log(LogStatus.ERROR, "'Ratings & Review' is NOT DISPLAYED as expected ");
				}

			} else {

			}
			Utils.waitForLoad(driver);
			Utils.scrollup();
		}

	}

	// *******************************************************************************************************************************
	/**
	 * Method Title: tc_sortFilter; Method Description: This Method validates on
	 * sort and filter options as well as the bread crumb. Author: Vandhana.S Date:
	 * 02/27/2018
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_sortFilter() {
		// Clicking on the Kitchen L1 and Navigating to PLP screen to validations
		Utils.sleep(2000);
		Actions action = new Actions(driver);
		driver.findElement(OR.Products).click();
		Utils.sleep(1000);
		action.pause(2)
				.moveToElement(driver.findElement(By.xpath("//*[@id='collegeBridalArea']/div[1]/div/ul/li[5]/a")))
				.pause(2)
				.moveToElement(driver.findElement(
						By.xpath("//*[@id='collegeBridalArea']/div[1]/div/ul/li[5]/div/div[1]/ul[1]/li[2]/a")))
				.pause(1).click().build().perform();

		// Validating on the Bread crumb
		if (Utils.isElementFound(By.xpath("//*[@id=\"subHeader\"]/div[1]/div/div"))) {
			extest.log(LogStatus.PASS,
					"'Bread Crumb' Home -> Kitchen -> Small Appliances -> Blenders is DISPLAYED as expected"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR,
					"'Bread Crumb' Home-> Kitchen -> Small Appliances -> Blenders is DISPLAYED as expected"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(4000);
		Utils.waitForLoad(driver);
		// Validating on the List View of the products.
		WebElement gridList = driver.findElement(By.xpath("//*[@title='List View']"));
		gridList.click();
		Utils.waitForLoad(driver);
		Utils.sleep(2000);
		if ((driver.findElement(By.xpath("//*[@class='prodListRow clearfix noMar']"))).isDisplayed()) {
			extest.log(LogStatus.PASS, "'List View Validation'--> data is DISPLAYED in a List view as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "'List View Validation'--> data is NOT DISPLAYED in a List View as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating on the 3 Grid View of the products.
		WebElement grid3 = driver.findElement(By.xpath("//*[@title='Product Grid View - 3 Across']"));
		grid3.click();
		Utils.waitForLoad(driver);
		Utils.sleep(2000);
		if ((driver.findElement(By.xpath("//*[@class='grid_9 noMar grid_3']"))).isDisplayed()) {
			extest.log(LogStatus.PASS, "'3 Grid Validation'--> data is DISPLAYED in 3 columns as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "'3 Grid Validation'--> data is NOT DISPLAYED in 3 columns as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating on the 4 Grid View of the products.
		WebElement grid4 = driver.findElement(By.xpath("//*[@title='Product Grid View - 4 Across']"));
		grid4.click();
		Utils.waitForLoad(driver);
		Utils.sleep(2000);
		if ((driver.findElement(By.xpath("//*[@class='grid_9 noMar ']"))).isDisplayed()) {
			extest.log(LogStatus.PASS, "'4 Grid Validation'--> data is DISPLAYED in 4 columns as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "'4 Grid Validation'--> data is NOT DISPLAYED in 4 columns as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Validating on the Sort Order
		WebElement selectsort = driver.findElement(By.id("pagSortOpt"));
		selectsort.click();
		// validating price low to high
		Utils.sleep(1000);
		new Select(selectsort).selectByVisibleText("Price - low to high");
		Utils.scrolldown();
		Utils.sleep(2000);
		List<WebElement> pricediff = driver.findElements(By.xpath("//*[@class='isPrice']"));
		WebElement firstitemprice = pricediff.get(0);
		String itemprice1 = firstitemprice.getText();
		itemprice1 = itemprice1.replace("$", "");
		itemprice1 = itemprice1.replace(" ", "");
		WebElement seconditemprice = pricediff.get(1);
		String itemprice2 = seconditemprice.getText();
		itemprice2 = itemprice2.replace("$", "");
		itemprice2 = itemprice2.replace(" ", "");
		double ip1 = 0;
		double ip2 = 0;
		if (itemprice1.contains("-")) {
			String[] itemprice1Array = itemprice1.split("-");
			String price1 = itemprice1Array[0];

			ip1 = Double.valueOf(price1);
		} else {
			ip1 = Double.valueOf(itemprice1);
		}
		if (itemprice2.contains("-")) {
			String[] itemprice2Array = itemprice2.split("-");
			String price2 = itemprice2Array[0];
			price2.replace("$", "");
			ip2 = Double.valueOf(price2);

		} else {
			ip2 = Double.valueOf(itemprice2);
		}
		// comparing the first and second price of the products
		if (ip1 <= ip2) {

			extest.log(LogStatus.PASS, "First item price'" + ip1 + "' is HIGHER than Second item price'" + ip2 + "'"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "First item price'" + ip1 + "' is NOT HIGHER than Second item price '" + ip2
					+ "'" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// validating the Price High To Low
		selectsort = driver.findElement(By.id("pagSortOpt"));
		selectsort.click();
		// validating price low to high
		Utils.sleep(1000);
		new Select(selectsort).selectByVisibleText("Price - low to high");
		Utils.scrolldown();
		Utils.sleep(2000);
		List<WebElement> pricediffs = driver.findElements(By.xpath("//*[@class='isPrice']"));
		WebElement firstIprice = pricediffs.get(0);
		String itemPrice1 = firstIprice.getText();
		itemPrice1 = itemPrice1.replace("$", "");
		itemPrice1 = itemPrice1.replace(" ", "");
		WebElement secondIprice = pricediffs.get(1);
		String itemPrice2 = secondIprice.getText();
		itemPrice2 = itemPrice2.replace("$", "");
		itemPrice2 = itemPrice2.replace(" ", "");
		double IP1 = 0;
		double IP2 = 0;
		if (itemprice1.contains("-")) {
			String[] itemprice1Array = itemPrice1.split("-");
			String price1 = itemprice1Array[0];

			IP1 = Double.valueOf(price1);
		} else {
			IP1 = Double.valueOf(itemPrice1);
		}
		if (itemprice2.contains("-")) {
			String[] itemprice2Array = itemPrice2.split("-");
			String price2 = itemprice2Array[0];
			price2.replace("$", "");
			IP2 = Double.valueOf(price2);

		} else {
			IP2 = Double.valueOf(itemPrice2);
		}
		// comparing the first and second price of the products
		if (IP1 <= IP2) {

			extest.log(LogStatus.PASS, "First item price'" + IP1 + "' is LOWER than Second item price'" + IP2 + "'"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "First item price'" + IP1 + "' is NOT LOWER than Second item price '" + IP2
					+ "'" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

	}
	
	// *******************************************************************************************************************************
	/**
	 * Method Title: tc_compareProducts; Method Description: This Method validates on the comparison of the products. 
	 * Author: Vandhana.S Date:
	 * 02/27/2018
	 */
	// ********************************************************************************************************************************
		
	@Test
	public void tc_compareProducts() {

		// hovering the mouse to select the Products
		Utils.sleep(2000);
		Actions action = new Actions(driver);
		WebElement products = driver.findElement(OR.Products);

		action.moveToElement(products).pause(2).moveToElement(driver.findElement(OR.Dining)).pause(2)
				.moveToElement(driver.findElement(OR.FineChina)).click().build().perform();
		Utils.waitForLoad(driver);
		Utils.sleep(3000);
		if (Utils.isElementFound(OR.L3Header)) {
			extest.log(LogStatus.PASS, "Selection of the 'Products' has been made for the comparision."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "Selection of the 'Products' was NOT made for the comparision."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(2000);
		Utils.scrolldown();
		// collecting the check boxes for 1st and 2nd products
		List<WebElement> chkbx = driver.findElements(OR.Comparechkbx);
		for (int i = 0; i <= 1; i++) {
			@SuppressWarnings("unused")
			boolean schkbx = false;
			schkbx = chkbx.get(i).isSelected();
			if (schkbx = true) {
				chkbx.get(i).click();
				int product = i + 1;
				extest.log(LogStatus.PASS, "Selected " + product + " to compare"
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
				Utils.sleep(2000);
			}
		}

		Utils.sleep(2000);
		// Validating the compare drawer
		WebElement CompareDrawer = driver.findElement(OR.CompareDrawer);
		if (CompareDrawer.isDisplayed()) {
			extest.log(LogStatus.PASS, "Compare Drawer is visible after adding the product to compare"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "Compare Drawer is NOT visible after adding the product to compare."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.clickelement(OR.CompareProducts);
		Utils.sleep(3000);
		Utils.clickelement(OR.AddAnotherItem);
		Utils.sleep(2000);
		// adding the third item to the compare
		Utils.clickelement(OR.ThirdItem);
		Utils.sleep(2000);
		extest.log(LogStatus.PASS,
				"Selected " + 3 + " product to compare." + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		Utils.clickelement(OR.CompareProducts);
		Utils.sleep(2000);
		extest.log(LogStatus.PASS,
				"List of products to compare are visible in the Compare screen with the choose options to select."
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		Utils.clickelement(OR.AddAnotherItmBck);
		Utils.sleep(2000);
		Utils.clickelement(OR.RemoveAll);
		Utils.sleep(2000);
		extest.log(LogStatus.PASS,
				"After clicking on the Remove All button the Compare Drawer does not have any items to compare.");

		WebElement CompareDrawer1 = driver.findElement(OR.CompareDrawer);
		if (CompareDrawer1.isDisplayed()) {
			extest.log(LogStatus.FAIL, "Compare Drawer is still visible even after removing all the Products."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.PASS, "Compare Drawer is NOT visible as expected after removing the all the Products."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
	}

	// *******************************************************************************************************************************
	/**
	 * Method Title: tc_compareProducts; Method Description: This Method validates on the comparison of the products. 
	 * Author: Vandhana.S Date:
	 * 02/27/2018
	 */
	// ********************************************************************************************************************************
	@Test	
	public void tc_LTL_Assembly() {
		
		//Validating the Truck Load 
		WebElement searchFormInput = driver.findElement(OR.InputsearchItem);
		String searchitem = testMethodData.get("SearchItem");
		searchFormInput.sendKeys(searchitem);
		extest.log(LogStatus.INFO,
				"Entering the SKU '" + searchitem + "'to validate the Truck Develivery option");

		WebElement searchButton = driver.findElement(OR.SearchItem);
		searchButton.click();
		Utils.waitForLoad(driver);
		WebElement searchresult = driver.findElement(OR.ProductName);
		String uiresults = searchresult.getAttribute("title");
		if (searchresult.isDisplayed()) {
			extest.log(LogStatus.PASS,  " "+ uiresults +" is DISPLAYED as result of the searched item" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL,  " "+ uiresults +" is NOT DISPLAYED as result of the searched item" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}	
		Utils.sleep(3000);
		searchresult.click();
		Utils.waitForLoad(driver);
		WebElement truckdelopt = driver.findElement(By.xpath("//span[contains(text(),'Truck Delivery Options :')]"));
		if(truckdelopt.isDisplayed()) {
			extest.log(LogStatus.PASS,  "Truck delivery option is VISIBLE for the searched item" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL,  "Truck delivery option is NOT VISIBLE for the searched item" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}	
		
		WebElement selectdeloption = driver.findElement(By.xpath("//a[@class='selectedIndex']"));
		selectdeloption.click();
		Utils.sleep(1000);
		new Select(selectdeloption).selectByIndex(0);
		Utils.sleep(1000);
		WebElement slctporch = driver.findElement(By.xpath("//*[@class='serviceAttachWidget-checkbox-input noUniform']"));
		if (slctporch.isEnabled()) {
			slctporch.clear();
			extest.log(LogStatus.PASS,  "Assembly option is VISIBLE for the searched item" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL,  "Assembly option is NOT VISIBLE for the searched item" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.clickelement(OR.AddtoCart);
		Utils.waitForLoad(driver);
		Utils.isElementFound(OR.CartSummary);
		if((driver.findElement(OR.CartSummary).isDisplayed())){
			extest.log(LogStatus.PASS,  "Cart Summary is DISPLAYED as expected" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL,  "Cart Summary is DISPLAYED as expected" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}	
		Utils.popUpCls();
		Utils.scrollup();
			
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
