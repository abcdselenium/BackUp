package com.bbb.util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelTestDataUtil {

	public static String excelFileName = "Desktop.xlsx";

	// public static void main(String[] args) throws Exception {
	public static Map<String, Map<String, String>> readExcelData() {
		Map<String, Map<String, String>> data = new HashMap<String, Map<String, String>>();
		try {
			XSSFWorkbook excelWBook = getExcelBook(excelFileName);
			XSSFSheet excelWSheet = excelWBook.getSheet("EnvironmentVariables");
			int totalRows = excelWSheet.getLastRowNum();
			for (int row = 1; row <= totalRows; row++) {
				String sheetName = getCellData(row, 0, excelWSheet);
				String browser = getCellData(row, 1, excelWSheet);
				String url = getCellData(row, 2, excelWSheet);
				String execution = getCellData(row, 4, excelWSheet);
				if ("Yes".equalsIgnoreCase(execution)) {
					Map<String, Map<String, String>> sheetData = readSheetData(sheetName, excelWBook, browser, url);
					data.putAll(sheetData);
				}
			}
			// Closing the excel work book(excelwbook)........
			excelWBook.close();
		} catch (Exception e) {
			 e.printStackTrace();
		}
		return data;

	}

	public static Map<String, Map<String, String>> readSheetData(String sheetName, XSSFWorkbook excelWBook,
			String browser, String url) {
		Map<String, Map<String, String>> data = new HashMap<String, Map<String, String>>();
		try {
			XSSFSheet excelWSheet = excelWBook.getSheet(sheetName);
			int totalRows = excelWSheet.getLastRowNum();
			for (int row = 1; row <= totalRows; ) {
				try {
					String testName = getCellData(row, 0, excelWSheet);
					String isActive = getCellData(row, 1, excelWSheet);
					String IsTestData = getCellData(row, 3, excelWSheet);
					
					if ("Yes".equalsIgnoreCase(isActive)) {
						Map<String, String> tData = new HashMap<String, String>();
						if("Yes".equalsIgnoreCase(IsTestData)) {
							tData = readTestCaseData(row, excelWSheet);
						}
						tData.put("rowNum", row + "");
						tData.put("sheetName", sheetName);
						tData.put("browser", browser);
						tData.put("url", url);
						data.put(testName, tData);
					}
					if("Yes".equalsIgnoreCase(IsTestData)) {
						row = row + 3;
					} else {
						row = row + 1;
					}
				} catch (Exception e) {
					 e.printStackTrace();
				}
			}
		} catch (Exception e) {
			 e.printStackTrace();
		}
		return data;
	}

	public static XSSFSheet getExcelSheet(String sheetName, XSSFWorkbook excelWBook) {
		XSSFSheet excelWSheet = null;
		try {
			excelWSheet = excelWBook.getSheet(sheetName);
		} catch (Exception e) {
			 e.printStackTrace();
		}
		return excelWSheet;
	}

	public static XSSFWorkbook getExcelBook(String fileName) {
		XSSFWorkbook excelWBook = null;
		try {
			FileInputStream excelFile = new FileInputStream(fileName);
			excelWBook = new XSSFWorkbook(excelFile);
		} catch (Exception e) {
			 e.printStackTrace();
		}
		return excelWBook;
	}

	public static void closeExcelWorkBook(XSSFWorkbook excelBook) {
		try {
			excelBook.close();
		} catch (IOException e) {
			 e.printStackTrace();
		}
	}

	public static Map<String, String> readTestCaseData(int row, XSSFSheet excelWSheet) {
		Map<String, String> tData = new HashMap<String, String>();
		try {
			int col = 4;
			while (true) {
				String label = getCellData((row + 1), col, excelWSheet);
				String value = getCellData((row + 2), col, excelWSheet);
				if (label != null && value != null && label.trim().length() > 0 && value.trim().length() > 0) {
					tData.put(label, value);
				}

				col++;
			}
		} catch (Exception e) {
			 e.printStackTrace();
		}
		return tData;
	}

	public static String getCellData(int rowNum, int colNum, XSSFSheet excelWSheet) {
		XSSFCell cell = excelWSheet.getRow(rowNum).getCell(colNum);
		CellType cellType = cell.getCellTypeEnum();
		String value = "";
		if (CellType.NUMERIC.equals(cellType)) {
			value = cell.getNumericCellValue() + "";
		} else if (CellType.STRING.equals(cellType)) {
			value = cell.getStringCellValue();
		}
		return value;
	}

	@SuppressWarnings("resource")
	public static void setCellData(int rowNum, int colNum, String sheetName, String value) {
		try {
			FileInputStream fis = new FileInputStream(excelFileName);
			XSSFWorkbook excelWBook = new XSSFWorkbook(fis);
			XSSFSheet sheet = excelWBook.getSheet(sheetName);
			Row row = sheet.getRow(rowNum);
			Cell cell = row.createCell(colNum);
			cell.setCellValue(value);
			FileOutputStream fos = new FileOutputStream(excelFileName);
			excelWBook.write(fos);
			fos.close();
			fis.close();
		} catch (Exception e) {
			 e.printStackTrace();
		}
	}

}