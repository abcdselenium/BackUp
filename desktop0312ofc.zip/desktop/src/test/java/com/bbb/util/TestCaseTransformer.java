package com.bbb.util;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.IAnnotationTransformer;
import org.testng.annotations.ITestAnnotation;

import com.bbb.AbstractTestCases;
import com.bbb.util.ExcelTestDataUtil;

public class TestCaseTransformer implements IAnnotationTransformer {

	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MMM_dd_HH_mm");

	public TestCaseTransformer() {
		String dirName = sdf.format(new Date());
		File f = new File(dirName);
		f.mkdir();
		AbstractTestCases.dirName = dirName;
		AbstractTestCases.extentReport = dirName + System.getProperty("file.separator") + "report_" + dirName + ".html";
		AbstractTestCases.excelData = ExcelTestDataUtil.readExcelData();
	}

	@Override
	public void transform(ITestAnnotation annotation, @SuppressWarnings("rawtypes") Class testClass,
			@SuppressWarnings("rawtypes") Constructor testConstructor, Method testMethod) {
		String mName = testMethod.getName();
		if (AbstractTestCases.excelData.containsKey(mName)) {
			annotation.setEnabled(true);
		} else {
			annotation.setEnabled(false);
			
		}
	}
}
