package com.bbb.desktop;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.bbb.AbstractTestCases;
import com.bbb.repository.OR;
import com.bbb.util.Utils;
import com.relevantcodes.extentreports.LogStatus;

public class Baby extends AbstractTestCases {

	/**
	 * Method Title: tc_compareStrollers Method Description: This Method validates
	 * on the compare option by selecting the Strollers and removing the Car Seats
	 * in the compare drawer. Author: Vandhana.S Date: 02/28/2018
	 */

	@Test
	public void tc_compareStrollers() {

		WebDriverWait driverWait = new WebDriverWait(driver, 4);
		driverWait.until(ExpectedConditions.or(ExpectedConditions.presenceOfElementLocated(By.id("sddZip")),
				ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='collegeBridalArea']/div[1]/a"))));
		if (driver.findElements(By.id("sddZip")).size() != 0) {
			driver.findElement(By.cssSelector("a[class*='ui-dialog-titlebar-close ui-corner-all']")).click();
		}

		Actions action = new Actions(driver);
		WebElement products = driver.findElement(OR.Products);
		action.moveToElement(products).moveToElement(driver.findElement(OR.Strollers))
				.moveToElement(driver.findElement(OR.FrameStrollers)).click().build().perform();
		Utils.waitForLoad(driver);
		if (Utils.isElementFound(OR.L3Header)) {
			extest.log(LogStatus.PASS, "Selection of the 'Frame Strollers' has been made for the comparision."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "Selection of the 'Frame Strollers' was NOT made for the comparision."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(2000);
		Utils.scrolldown();

		List<WebElement> chkbx = driver.findElements(OR.Comparechkbx);
		for (int i = 0; i <= 1; i++) {
			@SuppressWarnings("unused")
			boolean schkbx = false;
			schkbx = chkbx.get(i).isSelected();
			if (schkbx = true) {
				chkbx.get(i).click();
				int Stroller = i + 1;
				extest.log(LogStatus.PASS, "Selected " + Stroller + " Stroller to compare"
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
				Utils.sleep(2000);
			}
		}
		Utils.sleep(2000);

		WebElement CompareDrawer = driver.findElement(OR.CompareDrawer);
		if (CompareDrawer.isDisplayed()) {
			extest.log(LogStatus.PASS, "Compare Drawer is visible after adding the Strollers to compare"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "Compare Drawer is NOT visible after adding the Strollers to compare."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(2000);
		Utils.clickelement(OR.CompareProducts);
		Utils.sleep(3000);
		Utils.clickelement(OR.AddAnotherItem);
		Utils.sleep(3000);
		Utils.scrolldown();
		Utils.sleep(2000);
		Utils.clickelement(OR.ThirdItem);
		Utils.sleep(2000);
		extest.log(LogStatus.PASS, "Selected " + 3 + " Stroller to compare.");
		extest.addScreenCapture(Utils.captureScreenShot(driver));
		Utils.clickelement(OR.CompareProducts);
		Utils.sleep(2000);
		extest.addScreenCapture(Utils.captureScreenShot(driver));
		Utils.clickelement(OR.AddAnotherItmBck);
		Utils.sleep(2000);
		Utils.clickelement(OR.RemoveAll);
		extest.log(LogStatus.PASS,
				"After clicking on the Remove All button the Compare Drawer does not have any Strollers to compare.");
		Utils.sleep(2000);

		WebElement CompareDrawer1 = driver.findElement(OR.CompareDrawer);
		if (CompareDrawer1.isDisplayed()) {
			extest.log(LogStatus.FAIL, "Compare Drawer is still visible even after removing all the Strollers."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.PASS, "Compare Drawer is NOT visible as expected after removing the all the Strollers."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
	}

	/**
	 * Method Title: tc_compareCarSeats Method Description: This Method validates on
	 * the compare option by selecting the Car Seats and removing the Car Seats in
	 * the compare drawer. Author: Vandhana.S Date: 02/28/2018
	 */
	@Test
	public void tc_compareCarSeats() {

		WebDriverWait driverWait = new WebDriverWait(driver, 2);
		driverWait.until(ExpectedConditions.or(ExpectedConditions.presenceOfElementLocated(By.id("sddZip")),
				ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='collegeBridalArea']/div[1]/a"))));
		if (driver.findElements(By.id("sddZip")).size() != 0) {
			driver.findElement(By.cssSelector("a[class*='ui-dialog-titlebar-close ui-corner-all']")).click();
		}
		// hovering the mouse to select the infant car seats
		Actions action = new Actions(driver);
		WebElement products = driver.findElement(OR.Products);
		action.moveToElement(products).moveToElement(driver.findElement(OR.CarSeats))
				.moveToElement(driver.findElement(OR.InfantCarSeats)).click().build().perform();
		Utils.waitForLoad(driver);
		Utils.sleep(3000);
		if (Utils.isElementFound(OR.L3Header)) {
			extest.log(LogStatus.PASS, "Selection of the 'Infant Car Seats' has been made for the comparision."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "Selection of the 'Infant Car Seats' was NOT made for the comparision."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(2000);
		Utils.scrolldown();

		List<WebElement> chkbx = driver.findElements(OR.Comparechkbx);
		for (int i = 0; i <= 1; i++) {
			@SuppressWarnings("unused")
			boolean schkbx = false;
			schkbx = chkbx.get(i).isSelected();
			if (schkbx = true) {
				chkbx.get(i).click();
				int CarSeat = i + 1;
				extest.log(LogStatus.PASS, "Selected " + CarSeat + " Car seat to compare"
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
				Utils.sleep(2000);
			}
		}

		Utils.sleep(2000);

		WebElement CompareDrawer = driver.findElement(OR.CompareDrawer);
		if (CompareDrawer.isDisplayed()) {
			extest.log(LogStatus.PASS, "Compare Drawer is visible after adding the Car Seats to compare"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "Compare Drawer is NOT visible after adding the Car Seats to compare."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.clickelement(OR.CompareProducts);
		Utils.sleep(3000);
		Utils.clickelement(OR.AddAnotherItem);
		Utils.sleep(2000);

		Utils.clickelement(OR.ThirdItem);
		Utils.sleep(2000);
		extest.log(LogStatus.PASS,
				"Selected " + 3 + " Car seat to compare." + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		Utils.clickelement(OR.CompareProducts);
		Utils.sleep(2000);
		extest.log(LogStatus.PASS,
				"List of products to compare are visible in the Compare screen with the 'Add to Cart' & 'Add to Registry' options."
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		Utils.clickelement(OR.AddAnotherItmBck);
		Utils.sleep(2000);
		Utils.clickelement(OR.RemoveAll);
		extest.log(LogStatus.PASS,
				"After clicking on the Remove All button the Compare Drawer does not have any items to compare.");
		Utils.sleep(2000);

		WebElement CompareDrawer1 = driver.findElement(OR.CompareDrawer);
		if (CompareDrawer1.isDisplayed()) {
			extest.log(LogStatus.FAIL, "Compare Drawer is still visible even after removing all the Car Seats."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.PASS, "Compare Drawer is NOT visible as expected after removing the all the Car Seats."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
	}
}
