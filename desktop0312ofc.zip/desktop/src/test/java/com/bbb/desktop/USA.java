package com.bbb.desktop;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.bbb.AbstractTestCases;
import com.bbb.repository.OR;
import com.bbb.util.ExcelTestDataUtil;
import com.bbb.util.Utils;
import com.relevantcodes.extentreports.LogStatus;

public class USA extends AbstractTestCases {
	// ********************************************************************************************************************************
	/**
	 * Method Title: tc_homepage Method Description: This Methods validates the
	 * header links DISPLAYED on the home page. Author: Vandhana.S Date: 02/26/2018
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_homepage() throws InterruptedException {

		// Validating the Hero Image box--> Image cannot be validated, we are checking
		// if the banner is present.
		WebElement heroBanner = driver.findElement(OR.HeroBanner);
		if (Utils.isElementFound(OR.HeroBanner) && heroBanner.isDisplayed()) {
			extest.log(LogStatus.PASS, "'Hero Image and Banner' is DISPLAYED on the home page.");
		} else {
			extest.log(LogStatus.ERROR, "Hero Image and Banner' is NOT DISPLAYED on the home page."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Validating the Sister links visibility.
		String sisterlinks = testMethodData.get("SisterLinks");

		List<WebElement> allOptions = driver.findElements(OR.UISisterLinks);
		int allOptionsCount = allOptions.size();

		// Validating the Expected and UI options are same.
		for (int i = 0; i < allOptionsCount; i++) {
			String sisterlink = allOptions.get(i).getAttribute("title");
			if (sisterlinks.contains(sisterlink)) {
				extest.log(LogStatus.PASS, "Sister Link --> " + "'" + sisterlink + "'" + " is DISPLAYED as expected");
			} else {
				extest.log(LogStatus.ERROR,
						"Sister Link --> " + "'" + sisterlink + "'" + " is NOT DISPLAYED as expected");
			}
		}
		extest.addScreenCapture(Utils.captureScreenShot(driver));

		// Validating the Social annex(upload photo or Visit Gallery on home page)

		if (Utils.isElementFound(OR.SocialAnnex)) {
			Utils.clickelement(OR.SocialAnnex);
			Utils.sleep(2000);
			if (Utils.isElementFound(OR.SocialUpload)) {
				extest.log(LogStatus.PASS,
						"'Upload Photo / Visit Gallery' is DISPLAYED on the screen for the user to select the media to upload the pictures."
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			} else {
				extest.log(LogStatus.ERROR,
						"'Upload Photo / Visit Gallery' is NOT DISPLAYED on the screen for the user to select the media to upload the pictures."
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
			Utils.clickelement(OR.UploadWdwClose);
		}
		Utils.sleep(3000);
		Utils.scrollup();
		Utils.scrollup();

		// Validating the visual registry from promo box.

		// Utils.scrollToElement(OR.GiftPromoRgsrty);
		String UserFirstName = testMethodData.get("UFirstName");
		String UserLastname = testMethodData.get("ULastname");
		if (Utils.isElementFound(OR.GiftRegFirstN)) {
			Utils.entertext(OR.GiftRegFirstN, UserFirstName);
			if (Utils.isElementFound(OR.GiftRegLastN)) {
				Utils.entertext(OR.GiftRegFirstN, UserLastname);
			}
			Utils.clickelement(OR.SearchGRHomePg);
			Utils.sleep(3000);
		}
		if (Utils.isElementFound(OR.GiftRegistriesPg)) {
			extest.log(LogStatus.PASS,
					"'Gift Registries' screen DISPLAYED after giving the registry details in the promo box."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR,
					"'Gift Registries' screen is NOT DISPLAYED after giving the registry details in the promo box."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Validating the Trends & Ideas tab
		// Utils.scrollup();
		if (Utils.isElementFound(OR.TrendsNIdeas)) {
			WebElement trendsideas = driver.findElement(OR.TrendsNIdeas);
			trendsideas.click();
			Actions action = new Actions(driver);
			action.moveToElement(driver.findElement(OR.TrendsIdeasmerch)).perform();
			Utils.waitForLoad(driver);
			extest.log(LogStatus.PASS,
					"'Trends & Ideas' Merch template is visible when mouse is hovered on to the 'Trends & Ideas'"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR,
					"'Trends & Ideas' Merch template is NOT visible when mouse is hovered on to the 'Trends & Ideas'"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.clickelement(OR.BBBLink);
		// Validating the save to Idea Board from the Certona Container
		List<WebElement> heart = driver.findElements(OR.IBcertona);
		heart.get(3).click();
		Utils.sleep(2000);
		// Utils.isElementFound(OR.CreateIB);
		// Utils.clickelement(OR.CreateIB);
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(OR.CreateIB)).click();

		Utils.sleep(1000);
		String autoIBName = testMethodData.get("IdeaBoardName");
		Utils.entertext(OR.IBName, autoIBName);
		Utils.clickelement(OR.SaveIB);
		Utils.sleep(2000);

		WebElement ibgivenTitle = driver.findElement(OR.IBTitle);
		String ibTitle = ibgivenTitle.getText();
		if (ibTitle.contains(autoIBName)) {
			extest.log(LogStatus.PASS,
					"'Idea Board' is been created and the Title " + autoIBName
							+ " is DISPLAYED as given for the Title of Idea Board ."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR,
					"'Idea Board' is been created and the Title " + autoIBName
							+ " is NOT DISPLAYED as given for the Title of Idea Board ."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		Utils.clickelement(OR.Return);

		// Validating the College and Registry Tabs.
		if (Utils.isElementFound(By.id("shopForCollegeLink"))) {
			extest.log(LogStatus.PASS, "'College' Tab is visible on the Home Page as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "'College' Tab is NOT visible on the Home Page which is not expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		if (Utils.isElementFound(By.id("bridalGiftRegistryLink"))) {
			extest.log(LogStatus.PASS, "'Gift Registry' Tab is visible on the Home Page as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "'Gift Registry' Tab is NOT visible on the Home Page which is not expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		if (Utils.isElementFound(OR.Search)) {
			extest.log(LogStatus.PASS, "'Search Option' Tab is visible on the Home Page as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "'Search Option' Tab is NOT visible on the Home Page which is not expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Validating the Sign In Icon
		if (Utils.isElementFound(OR.SignIn)) {
			extest.log(LogStatus.PASS, "'Sign In/Account Icon' has been DISPLAYED as expected."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "'Sign In/Account Icon' is DISPLAYED as expected."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating the Heart Icon
		if (Utils.isElementFound(OR.Heart)) {
			Utils.clickelement(OR.Heart);
			Utils.waitForLoad(driver);
			if (Utils.isElementFound(OR.CreateIdeaBoard)) {
				extest.log(LogStatus.PASS,
						"'Heart Icon' has been DISPLAYED as expected and is navigated to the Ideaboard home page after clicking on it."
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			} else {
				extest.log(LogStatus.ERROR,
						"'Heart Icon' is NOT DISPLAYED or is NOT navigated to the IdeaBoard homepage which is not expected"
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
		}
		// Validating the Cart Icon
		if (Utils.isElementFound(OR.Cart)) {
			extest.log(LogStatus.PASS, "'Cart Icon' has been DISPLAYED as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "'Cart con' is NOT DISPLAYED which is not expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating 'Find a Store' Link
		driver.findElement(OR.FindAStore).click();
		Utils.waitForLoad(driver);
		WebElement storelocator = driver.findElement(OR.StoreLocator);
		if (storelocator.isDisplayed()) {
			extest.log(LogStatus.PASS,
					"'Find A Store' Link has been SUCCESSFULLY directed to the Store Locator screen to enter the Location Details"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR,
					"'Find A Store' Link was NOT directed to the Store Locator screen to enter the Location Details as expected"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating 'You May Like' Link
		driver.findElement(OR.YouMayLike).click();
		Utils.waitForLoad(driver);
		WebElement recommendations = driver.findElement(OR.OurRecommendations);
		if (recommendations.isDisplayed()) {
			extest.log(LogStatus.PASS,
					"'You May Like' Link has been SUCCESSFULLY directed to the 'Our Recommendations' screen with the suggestions."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR,
					"'You May Like' Link was NOT directed to the 'Our Recommendations' screen suggestions as expected."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		/*
		 * // Validating 'Sign Up For Offers' Link WebElement SignUpForOffers =
		 * driver.findElement(OR.SignUpForOffers); WebElement MyOffers =
		 * driver.findElement(OR.MyOffers); if (SignUpForOffers.isDisplayed()) {
		 * extest.log(LogStatus.PASS,
		 * "'Sign Up For Offers' Link has been SUCCESSFULLY DISPLAYED on the screen.");
		 * }else if (MyOffers.isDisplayed()) { extest.log(LogStatus.PASS,
		 * "'Sign Up For Offers' Link has been SUCCESSFULLY DISPLAYED on the screen.");
		 * } Utils.waitForLoad(driver);
		 */
		// Validating 'Track Order' Link
		driver.findElement(OR.TrackOrder).click();
		Utils.waitForLoad(driver);
		WebElement OrderTracking = driver.findElement(OR.OrderTracking);
		if (OrderTracking.isDisplayed()) {
			extest.log(LogStatus.PASS,
					"'Track Order' Link has been SUCCESSFULLY directed to the 'Order Tracking' screen."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "'Track Order' Link was NOT directed to the 'Track Order' screen as expected."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating the 'Contact US' Link
		/*
		 * driver.findElement(OR.ContactUS).click(); Utils.sleep(3000);
		 * Utils.waitForLoad(driver); WebElement ContactUspage =
		 * driver.findElement(OR.ContactUsPage); if (ContactUspage.isDisplayed()) {
		 * extest.log(LogStatus.PASS,
		 * "'Contact US' Link has been SUCCESSFULLY directed to the 'Contact US' screen."
		 * ); extest.addScreenCapture(Utils.captureScreenShot(driver)); } else {
		 * extest.log(LogStatus.ERROR,
		 * "'Contact US' Link was NOT directed to the 'Contact US' screen as expected."
		 * ); extest.addScreenCapture(Utils.captureScreenShot(driver)); }
		 */
		// Validating the link is DISPLAYED Gift Cards
		WebElement giftcards = driver.findElement(OR.GiftCards);
		if (giftcards.isDisplayed()) {
			extest.log(LogStatus.PASS, "'Gift Cards' Link is DISPLAYED on the home page.");
		} else {
			extest.log(LogStatus.ERROR, "Gift Cards' Link is NOT DISPLAYED on the home page."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Validating the International Shipping

		Utils.clickelement(OR.ShipTo);
		Utils.sleep(2000);
		if (Utils.isElementFound(OR.Internationalshppng)) {
			if ((Utils.isElementFound(OR.SelectCountry))) {
				extest.log(LogStatus.PASS, "Select Country is DISPLAYED to select the desired Country."
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			} else {
				extest.log(LogStatus.ERROR, "Select Country is NOT DISPLAYED to select the desired Country"
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
			if ((Utils.isElementFound(OR.SelectCurrency))) {
				extest.log(LogStatus.PASS, "Select Currency is DISPLAYED to select the desired Country."
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			} else {
				extest.log(LogStatus.ERROR, "Select Currency is NOT DISPLAYED to select the desired Country"
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
		}
		if (Utils.isElementFound(OR.Clsshipto)) {
			Utils.clickelement(OR.Clsshipto);
			Utils.sleep(3000);
			Utils.waitForLoad(driver);
		}

		Utils.clickelement(OR.BBBLink);
		Utils.sleep(3000);
		Utils.scrolldown();

	}

	// *******************************************************************************************************************
	/**
	 * Method Title: tc_accountcreation Method Description: This Method validates on
	 * the new account creation and the options available for the user. Author:
	 * Vandhana.S Date: 02/27/2018
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_accountcreation() {

		// Clicking on the SignIn/Account to Initiate the new account process.
		Utils.clickelement(OR.SignIn);
		// Creating the New Account for the User.
		String UserEmail = Utils.random();
		// Insert the UserName to the excel sheet
		Utils.entertext(OR.NewEmailID, UserEmail);
		Utils.clickelement(OR.CreateNewAcctPg1);
		Utils.sleep(1000);

		String UserFirstName = testMethodData.get("UFirstName");
		String UserLastname = testMethodData.get("ULastname");
		String Pswd = testMethodData.get("Password");
		String Invalidpswd = testMethodData.get("InvalidPassword");
		Utils.entertext(OR.FirstName, UserFirstName);
		Utils.entertext(OR.LastName, UserLastname);
		Utils.entertext(OR.NewPswd, Invalidpswd);
		Utils.sleep(1000);
		extest.log(LogStatus.INFO, "Error Msg for 'Password Requirement' is displayed to enter the valid password. "
				+ extest.addScreenCapture(Utils.captureScreenShot(driver)));

		driver.findElement(OR.NewPswd).clear();
		Utils.sleep(1000);
		Utils.scrolldown();
		Utils.entertext(OR.NewPswd, Pswd);
		Utils.entertext(OR.NewCnfrmPswd, Pswd);
		extest.log(LogStatus.PASS,
				"'Details with - User Email: " + UserEmail + ", First Name: " + UserFirstName + ", Last Name: "
						+ UserLastname + " and Password: " + Pswd + " have been entered to create an account.");

		String rowNum = testMethodData.get("rowNum");
		String sheetName = testMethodData.get("sheetName");
		ExcelTestDataUtil.setCellData(Integer.valueOf(rowNum) + 2, 4, sheetName, UserEmail);

		extest.addScreenCapture(Utils.captureScreenShot(driver));
		Utils.clickelement(OR.CreateNewAcctPg2);

		// Validating the Congratulations message after the User account is created.

		if (driver.findElement(OR.CongratsMsg).isDisplayed()) {
			extest.log(LogStatus.PASS, "Congratulations! Your account has now been created."
					+ "Message is DISPLAYED as expected" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR,
					"Congratulations! Your account has now been created." + "Message is NOT DISPLAYED as expected"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating UserName is DISPLAYED on the right top corner near the heart icon.
		String UIUserName = driver.findElement(OR.UserName).getText();
		if (UIUserName.contains(UserFirstName)) {
			extest.log(LogStatus.PASS, "User First Name '" + UserFirstName + "' is DISPLAYED as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "User Name is NOT DISPLAYED as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating the User is able to see the My Account OverView.
		if (driver.findElement(OR.MyAccountVal).isDisplayed()) {
			extest.log(LogStatus.PASS, "User is been directed to the 'My Account' Page"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.PASS, "User cannot see the Options for the My Account screen "
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Validating if the User is able to see all the options related to 'My Account.
		String myaccountoptions = testMethodData.get("MyAccountOptions");

		List<WebElement> allOptions = driver.findElements(By.xpath("//*[@id='content']/div[2]/div/ul/li"));
		int allOptionsCount = allOptions.size();

		// Validating the Expected and UI options are same.
		for (int i = 0; i < allOptionsCount; i++) {
			String optionValue = allOptions.get(i).getText();
			if (myaccountoptions.contains(optionValue)) {
				extest.log(LogStatus.PASS,
						"My Account Option -> " + "'" + optionValue + "'" + " is DISPLAYED as expected");
			} else {
				extest.log(LogStatus.ERROR,
						"My Account Option -> " + "'" + optionValue + "'" + " is NOT DISPLAYED as expected");
			}
		}
		extest.addScreenCapture(Utils.captureScreenShot(driver));

		// Logging Out of the application.
		Utils.clickelement(OR.LogOutMyAccount);
		Utils.sleep(2000);
		if ((Utils.isElementFound(OR.SignIn))) {
			extest.log(LogStatus.PASS, "User Logged out of the Application Succesfully"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "User could NOT Log Out of the Application Succesfully"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
	}

	// *******************************************************************************************************************************
	/**
	 * Method Title: tc_SearchItem Method Description: This Method validates on
	 * search option to validate the user is able to see the search related items.
	 * Author: Vandhana.S Date: 02/27/2018
	 */
	// ********************************************************************************************************************************
	// In PROGRESS ---> will be needed to work on this for regression suite.
	@Test
	public void tc_SearchItem() {

		// Searching for a specific item
		WebElement searchFormInput = driver.findElement(OR.InputsearchItem);
		Utils.sleep(3000);
		String searchitem1 = testMethodData.get("SearchItem_1");
		searchFormInput.sendKeys(searchitem1);
		extest.log(LogStatus.INFO,
				"Entering the item '" + searchitem1 + "'to check the result, DISPLAYED as per the search");

		WebElement searchButton = driver.findElement(OR.SearchItem);
		searchButton.click();
		Utils.sleep(2000);
		WebElement searchresult = driver.findElement(OR.ProductName);
		String uiresults = searchresult.getAttribute("title");
		if (searchitem1.equals(uiresults)) {
			extest.log(LogStatus.PASS, "The DISPLAYED item '" + uiresults + "'is the same as the search item '"
					+ searchitem1 + "'." + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "The DISPLAYED item '" + uiresults + "'is NOT the same as the search item '"
					+ searchitem1 + "'." + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		searchFormInput = driver.findElement(OR.InputsearchItem);
		String searchitem2 = testMethodData.get("SearchItem_2");
		searchFormInput.sendKeys(searchitem2);
		searchButton = driver.findElement(OR.SearchItem);
		extest.log(LogStatus.INFO,
				"Entering the item '" + searchitem2 + "'to check the result, DISPLAYED as per the search");
		searchButton.click();

		List<WebElement> list = driver.findElements(
				By.xpath("//*[@id='facetGroupContainer']/fieldset[2]/div[2]/div[2]/ul/li[1]/label/p/span[2]"));

		List<WebElement> checkboxList = driver.findElements(By.xpath("//*[@id='BRAND_0']"));

		if (list.size() > 0 && checkboxList.size() > 0) {

			WebElement brand = list.get(0);
			String count = brand.getText();
			count = count.trim();
			count = count.substring(1, count.length() - 1);
			checkboxList.get(0).click();
		}

	}

	// ********************************************************************************************************************************
	/**
	 * Method Title: tc_ideaboard; Method Description: This Method validates on Idea
	 * Boards and the options available for the user. Author: Vandhana.S Date:
	 * 02/27/2018
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_ideaboard() throws InterruptedException

	{
		//Creating a new UserAccount to validate the IdeaBoard concept
		Utils.tc_newUAccount();
		Utils.sleep(1000);
		String ideaboardname1 = testMethodData.get("IdeaBoard1");
		String ideaboardname2 = testMethodData.get("IdeaBoard2");
		String searchItem1 = testMethodData.get("SearchItem1");
		String addNotes = testMethodData.get("AddNotes");
		Utils.entertext((OR.Search), searchItem1);
		Utils.clickelement(OR.SearchItem);
		Utils.waitForLoad(driver);
		List<WebElement> heart = driver.findElements(OR.IBcertona);
		heart.get(0).click();
		Utils.sleep(2000);
		Utils.clickelement(OR.UserCreateIB);
		Utils.sleep(1000);
		Utils.entertext(OR.NewBoardName, ideaboardname1);
		Utils.clickelement(OR.SaveIB);
		Utils.sleep(3000);
		heart.get(0).click();
		Utils.sleep(1000);
		WebElement addtoIB1 = driver.findElement(By.xpath("//span[contains(text(),'" + ideaboardname1 + "')]"));
		if (addtoIB1.isDisplayed()) {
			extest.log(LogStatus.PASS, "The IdeaBoard " + ideaboardname1 + " has been CREATED"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.PASS, "The IdeaBoard " + ideaboardname1 + " is NOT CREATED"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(2000);
		WebElement closePopup = driver.findElement(OR.IBpopclsbtn);
		if (closePopup.isDisplayed()){
			closePopup.click();
		}
		heart.get(1).click();
		Utils.sleep(2000);
		addtoIB1 = driver.findElement(By.xpath("//span[contains(text(),'" + ideaboardname1 + "')]"));
		addtoIB1.click();
		Utils.sleep(3000);
		heart.get(2).click();
		Utils.sleep(1000);
		Utils.clickelement(OR.UserCreateIB);
		Utils.sleep(1000);
		Utils.entertext(OR.NewBoardName, ideaboardname2);
		Utils.clickelement(OR.SaveIB);
		Utils.sleep(3000);
		Utils.scrolldown();
		heart.get(3).click();
		WebElement addtoIB2 = driver.findElement(By.xpath("//span[contains(text(),'" + ideaboardname2 + "')]"));
		if (addtoIB2.isDisplayed()) {
			extest.log(LogStatus.PASS,
					"The second IdeaBoard " + ideaboardname2
							+ " has been CREATED and the item is added to the Idea Board"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.PASS,
					"The second IdeaBoard " + ideaboardname2 + " is NOT CREATED to add the item to Idea Board"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		addtoIB2 = driver.findElement(By.xpath("//span[contains(text(),'" + ideaboardname2 + "')]"));
		addtoIB2.click();
		Utils.sleep(3000);
		Utils.clickelement(OR.UserName);
		Utils.sleep(2000);
		if (driver.findElement(OR.UserIBMyAccount).isDisplayed()) {
			Utils.clickelement(OR.UserIBMyAccount);
		}		
		Utils.sleep(2000);
		WebElement userIB = driver.findElement(By.xpath("//*[contains(text(),'" + ideaboardname1 + "')]"));
		userIB.click();
		Utils.sleep(2000);
		List<WebElement> addnotes = driver.findElements(By.xpath("//*[contains(text(),'Add Note')]"));
		addnotes.get(0).click();
		Utils.sleep(2000);
		Utils.entertext(OR.AddNotes, addNotes);
		Utils.clickelement(OR.SaveNote);
		Utils.sleep(3000);
		WebElement addNotetitle = driver.findElement(By.xpath("//span[contains(text(),'" + addNotes + "')]"));
		if (addNotetitle.isDisplayed()) {
			extest.log(LogStatus.PASS, "Notes with " + ideaboardname2 + " has been UPDATED to the Idea Board"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.PASS, "Notes with " + ideaboardname2 + " has NOT been UPDATED to the Idea Board"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(2000);
		List<WebElement> ibOptions = driver.findElements(By.xpath("//*[@class='ideaBoardMore_icon']"));
		ibOptions.get(0).click();
		List<WebElement> ibMove = driver.findElements(By.xpath("//*[@class='movetxt']"));
		ibMove.get(0).click();
		WebElement movetoIB = driver.findElement(By.xpath("//span[contains(text(),'" + ideaboardname2 + "')]"));
		if (movetoIB.isDisplayed()) {
			movetoIB.click();
			extest.log(LogStatus.PASS, "The item has been MOVED to the " + ideaboardname2 + " Idea Board"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.PASS, "The item has NOT been MOVED to the " + ideaboardname2 + " Idea Board"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(2000);
		Utils.clickelement(By.xpath("//a[contains(text(),'My Idea Boards')]"));
		ibOptions = driver.findElements(By.xpath("//*[@class='ideaBoardMore_icon']"));
		ibOptions.get(1).click();
		WebElement delIB = driver.findElement(By.xpath("//*[@class='deletetxt']"));
		if (delIB.isEnabled()) {
			delIB.click();
			WebElement deleteIB = driver.findElement(By.xpath("//*[@id='deleteBoardBtn']"));
			deleteIB.click();
			extest.log(LogStatus.PASS, "The IdeaBoard " + ideaboardname2 + "was DELETED"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.PASS, "The IdeaBoard " + ideaboardname2 + "was NOT DELETED"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		Utils.clickelement(OR.UserName);
		Utils.sleep(2000);
		Utils.clickelement(OR.LogOutMyAccount);

		Utils.waitForLoad(driver);

	}

	// *******************************************************************************************************************************
	/**
	 * Method Title: tc_SearchItem Method Description: This Method validates on
	 * search option to validate the user is able to see the search related items.
	 * Author: Vandhana.S Date: 02/27/2018
	 */
	// ********************************************************************************************************************************

	@Test
	public void tc_PLP_PDP() {

		int noOfPLPPDPs = 4;// (testMethodData.get("NoOfPLPPDPs")).length();

		for (int i = 3; i <= noOfPLPPDPs; i++) {
			
			Actions action = new Actions(driver);
			driver.findElement(OR.Products).click();
			Utils.sleep(2000);
			action
					// .moveToElement(driver.findElement(By.xpath("//*[@title='shop products']")))
					.moveToElement(
							driver.findElement(By.xpath("//*[@id='collegeBridalArea']/div[1]/div/ul/li[" + i + "]/a")))
					.pause(1)
					.moveToElement(driver.findElement(By.xpath(
							"//*[@id='collegeBridalArea']/div[1]/div/ul/li[" + i + "]/div/div[1]/ul[1]/li[2]/a")))
					.pause(1).click().build().perform();
			Utils.waitForLoad(driver);

			if (Utils.isElementFound(By.xpath("//*[@id='row1']/div[1]"))) {
				extest.log(LogStatus.PASS, "First Row and Column is DISPLAYED AS EXPECTED");
			} else {
				extest.log(LogStatus.ERROR, "First Row and Column is NOT DISPLAYED AS EXPECTED");
			}

			if (Utils.isElementFound(By.xpath("//*[@id='row1']/div[2]"))) {
				extest.log(LogStatus.PASS, "Second Row and Column is DISPLAYED AS EXPECTED");
			} else {
				extest.log(LogStatus.ERROR, "Second Row and Column is NOT DISPLAYED AS EXPECTED");
			}

			if (Utils.isElementFound(By.xpath("//*[@id='row1']/div[3]"))) {
				extest.log(LogStatus.PASS, "Third Row and Column is DISPLAYED AS EXPECTED");
			} else {
				extest.log(LogStatus.ERROR, "Third Row and Column is NOT DISPLAYED AS EXPECTED");
			}

			String productTitle = "";
			if (Utils.isElementFound(By.xpath("//*[@id='row1']/div[1]/div[2]/div[3]/div[1]/a"))) {
				WebElement titleElement = driver.findElement(By.xpath("//*[@id='row1']/div[1]/div[2]/div[3]/div[1]/a"));
				productTitle = titleElement.getText();
				extest.log(LogStatus.INFO,
						"The item " + productTitle + "has been selected in PLP screen to be navigated to PDP screen"
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
				titleElement.click();
				Utils.waitForLoad(driver);

				WebElement proTitleElement = driver.findElement(By.xpath("//*[@id='productTitle']"));
				String displayedtitle = proTitleElement.getText();
				System.out.println(displayedtitle);
				if (productTitle.equalsIgnoreCase(displayedtitle)) {
					extest.log(LogStatus.PASS,
							"The item displayed " + displayedtitle + " is the same as Selected in PLP screen."
									+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
				} else {
					extest.log(LogStatus.FAIL,
							"The item displayed " + displayedtitle + " is NOT the same as Selected in PLP screen."
									+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
				}

				By prodView = By.xpath("//*[@id='prodViewDefault-tab1']/a");
				// Utils.scrolldown(1600);
				Utils.scrolldown();
				if (Utils.isElementFound(prodView)) {
					extest.log(LogStatus.PASS, "'Product Information' is DISPLAYED as expected ");
				} else {
					extest.log(LogStatus.ERROR, "'Product Information' is NOT DISPLAYED as expected ");
				}

				By ratingView = By.xpath("//*[@id='prodViewDefault-tab2']/a");
				if (Utils.isElementFound(ratingView)) {
					extest.log(LogStatus.PASS, "'Ratings & Review' is DISPLAYED as expected ");
				} else {
					extest.log(LogStatus.ERROR, "'Ratings & Review' is NOT DISPLAYED as expected ");
				}

				By verifyView = By.xpath("//*[@id='prodViewDefault-tab3']/a");
				if (Utils.isElementFound(verifyView)) {
					extest.log(LogStatus.PASS, "'Ratings & Review' is DISPLAYED as expected ");
				} else {
					extest.log(LogStatus.ERROR, "'Ratings & Review' is NOT DISPLAYED as expected ");
				}

			} else {

			}
			Utils.waitForLoad(driver);
			Utils.scrollup();
		}

	}
	
	
		
	
	

}
