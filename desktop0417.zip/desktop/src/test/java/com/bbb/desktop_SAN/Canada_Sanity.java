package com.bbb.desktop_SAN;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import com.bbb.AbstractTestCases;
import com.bbb.repository.OR;
import com.bbb.util.*;
import com.relevantcodes.extentreports.LogStatus;

public class Canada_Sanity extends AbstractTestCases {
	
	// ********************************************************************************************************************************
	/*
	 * Method Title: tc_homepage_CA Method Description: This Methods validates the
	 * header links DISPLAYED on the home page. Author: Vandhana.S
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_homepage_CA() throws InterruptedException {

		/*// Validating the Hero Image box--> Image cannot be validated, so validating if
		// the banner exists.
		WebElement heroBanner = driver.findElement(OR.HeroBanner);
		if (Utils.isElementFound(OR.HeroBanner) && heroBanner.isDisplayed()) {
			extest.log(LogStatus.PASS, "'Hero Image and Banner' is DISPLAYED on the home page.");
		} else {
			extest.log(LogStatus.ERROR, "Hero Image and Banner' is NOT DISPLAYED on the home page."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		if (Utils.isElementFound(OR.BabyCanada)) {
			Utils.clickelement(OR.BabyCanada);
			Utils.sleep(2000);
			if (Utils.isElementFound(By.xpath("//h2[contains(text(),'Categories')]"))) {
				extest.log(LogStatus.PASS, "'Buy Buy BABY'Logo is Displayed and  is DISPLAYED after clicking on the Buy Buy Baby logo"
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
		} else {
			extest.log(LogStatus.ERROR, "'Buy Buy BABY' Logo is NOT DISPLAYED on the home page");
		}
		Utils.clickelement(OR.BBBCanada);
		Utils.sleep(2000);
*/
		if (Utils.isElementFound(OR.SocialAnnex)) {
			Utils.scrolldown(1600);;
			Utils.clickelement(OR.SocialAnnex);
			Utils.sleep(2000);
			if (Utils.isElementFound(OR.SocialUpload)) {
				extest.log(LogStatus.PASS,
						"'Upload Photo / Visit Gallery' is DISPLAYED on the screen for the user to select the media to upload the pictures."
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			} else {
				extest.log(LogStatus.FAIL,
						"'Upload Photo / Visit Gallery' is NOT DISPLAYED on the screen for the user to select the media to upload the pictures."
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
			Utils.clickelement(OR.UploadWdwClose);
		}
		Utils.sleep(3000);

		// Validating the visual registry from promo box.

		// Utils.scrollToElement(OR.GiftPromoRgsrty);
		String UserFirstName = testMethodData.get("UFirstName");
		String UserLastname = testMethodData.get("ULastname");
		Utils.scrollup(350);
		
		if (Utils.isElementFound(OR.GiftRegFirstN)) {
			Utils.entertext(OR.GiftRegFirstN, UserFirstName);
			if (Utils.isElementFound(OR.GiftRegLastN)) {
				Utils.entertext(OR.GiftRegFirstN, UserLastname);
			}
			Utils.clickelement(OR.SearchGRHomePg);
			Utils.sleep(1000);
		}
		if (Utils.isElementFound(OR.GiftRegistriesPg)
				&& (Utils.isElementFound(By.xpath("//*[@class='regSearchListItems viewRegSolrBtn']")))) {
			extest.log(LogStatus.PASS,
					"'Gift Registries' screen DISPLAYED after giving the registry details in the promo box."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL,
					"'Gift Registries' screen is NOT DISPLAYED after giving the registry details in the promo box."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		Utils.clickelement(OR.BBBCanada);
		Utils.waitForLoad(driver);
		Utils.scrolldown();
		// Validating the save to Idea Board from the Certona Container
		List<WebElement> heart = driver.findElements(OR.IBcertona);
		heart.get(3).click();
		Utils.waitForLoad(driver);
		Utils.clickelement(OR.CreateIB);
		Utils.sleep(2000);
		String autoIBName = testMethodData.get("IdeaBoardName");
		Utils.entertext(OR.IBName, autoIBName);
		Utils.clickelement(OR.SaveIB);
		Utils.sleep(4000);
		heart.get(2).click();

		WebElement ibgivenTitle = driver.findElement(By.xpath("//*[@class='iBNameText']"));
		String ibTitle = ibgivenTitle.getText();
		if (ibTitle.equalsIgnoreCase(autoIBName)) {
			extest.log(LogStatus.PASS,
					"'Idea Board' is been created and the Title " + autoIBName
							+ " is DISPLAYED as given for the Title of Idea Board ."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "'Idea Board' creation have some issues."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		Utils.clickelement(By.xpath("//*[@class='ui-icon ui-icon-closethick']"));
		Utils.scrollup();
		// Validating the College and Registry Tabs.
		if (Utils.isElementFound(By.id("shopForCollegeLink"))) {
			extest.log(LogStatus.PASS, "'University' Tab is visible on the Home Page as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "'University' Tab is NOT visible on the Home Page which is not expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		if (Utils.isElementFound(By.id("bridalGiftRegistryLink"))) {
			extest.log(LogStatus.PASS, "'Gift Registry' Tab is visible on the Home Page as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "'Gift Registry' Tab is NOT visible on the Home Page which is not expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		if (Utils.isElementFound(OR.Search)) {
			extest.log(LogStatus.PASS, "'Search Option' Tab is visible on the Home Page as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "'Search Option' Tab is NOT visible on the Home Page which is not expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Validating the Sign In Icon
		if (Utils.isElementFound(OR.SignIn)) {
			extest.log(LogStatus.PASS, "'Sign In/Account Icon' has been DISPLAYED as expected."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "'Sign In/Account Icon' is DISPLAYED as expected."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating the Heart Icon
		if (Utils.isElementFound(OR.Heart)) {
			Utils.clickelement(OR.Heart);
			Utils.waitForLoad(driver);
			if (Utils.isElementFound(OR.CreateIdeaBoard)) {
				extest.log(LogStatus.PASS,
						"'Heart Icon' has been DISPLAYED as expected and is navigated to the Ideaboard home page after clicking on it."
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			} else {
				extest.log(LogStatus.FAIL,
						"'Heart Icon' is NOT DISPLAYED or is NOT navigated to the IdeaBoard homepage which is not expected"
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
		}
		// Validating the Cart Icon
		if (Utils.isElementFound(OR.Cart)) {
			extest.log(LogStatus.PASS, "'Cart Icon' has been DISPLAYED as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "'Cart con' is NOT DISPLAYED which is not expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating 'Find a Store' Link
		driver.findElement(OR.FindAStore).click();
		WebElement storelocator = driver.findElement(OR.StoreLocations);
		if (storelocator.isDisplayed()) {
			extest.log(LogStatus.PASS,
					"'Find A Store' Link has been SUCCESSFULLY directed to the Store Locator screen to enter the Location Details"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL,
					"'Find A Store' Link was NOT directed to the Store Locator screen to enter the Location Details as expected"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating 'You May Like' Link
		driver.findElement(OR.YouMayLike).click();
		Utils.waitForLoad(driver);
		WebElement recommendations = driver.findElement(OR.OurRecommendations);
		if (recommendations.isDisplayed()) {
			extest.log(LogStatus.PASS,
					"'You May Like' Link has been SUCCESSFULLY directed to the 'Our Recommendations' screen with the suggestions."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL,
					"'You May Like' Link was NOT directed to the 'Our Recommendations' screen suggestions as expected."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Validating 'Track Order' Link
		driver.findElement(OR.TrackOrder).click();
		Utils.waitForLoad(driver);
		WebElement OrderTracking = driver.findElement(OR.OrderTracking);
		if (OrderTracking.isDisplayed()&&(driver.findElement(By.id("emailOrderTrack")).isDisplayed())) {
			extest.log(LogStatus.PASS,
					"'Track Order' Link has been SUCCESSFULLY directed to the 'Order Tracking' screen."
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "'Track Order' Link was NOT directed to the 'Track Order' screen as expected."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		/*Has Captcha Issue
		// Validating the 'Contact US' Link
		driver.findElement(OR.ContactUS).click();
		Utils.sleep(3000);
		Utils.waitForLoad(driver);
		WebElement ContactUspage = driver.findElement(OR.ContactUsPage);
		if (ContactUspage.isDisplayed()) {
			extest.log(LogStatus.PASS, "'Contact US' Link has been SUCCESSFULLY directed to the 'Contact US' screen.");
			extest.addScreenCapture(Utils.captureScreenShot(driver));
		} else {
			extest.log(LogStatus.ERROR, "'Contact US' Link was NOT directed to the 'Contact US' screen as expected.");
			extest.addScreenCapture(Utils.captureScreenShot(driver));
		}
		 */
		// Validating the link is DISPLAYED Gift Cards
		WebElement giftcards = driver.findElement(OR.GiftCards);
		if (giftcards.isDisplayed()) {
			extest.log(LogStatus.PASS, "'Gift Cards' Link is DISPLAYED on the home page.");
		} else {
			extest.log(LogStatus.FAIL, "Gift Cards' Link is NOT DISPLAYED on the home page."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
	}

	// *******************************************************************************************************************
	/*
	 * Method Title: tc_newAcctandIdeaBoard_CA Method Description: This Method validates on
	 * the new account creation and the options available for the user. Author:
	 * Vandhana.S
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_newAcctandIdeaBoard_CA() {

		// Clicking on the SignIn/Account to Initiate the new account process.
		Utils.clickelement(OR.SignIn);
		// Creating the New Account for the User.
		String UserEmail = Utils.random();
		// Insert the UserName to the excel sheet
		Utils.entertext(OR.NewEmailID, UserEmail);
		Utils.clickelement(OR.CreateNewAcctPg1);
		Utils.sleep(1000);

		String UserFirstName = testMethodData.get("UFirstName");
		String UserLastname = testMethodData.get("ULastname");
		String Pswd = testMethodData.get("Password");
		String Invalidpswd = testMethodData.get("InvalidPassword");
		Utils.entertext(OR.FirstName, UserFirstName);
		Utils.entertext(OR.LastName, UserLastname);
		Utils.entertext(OR.NewPswd, Invalidpswd);
		Utils.sleep(1000);
		extest.log(LogStatus.INFO, "Error Msg for 'Password Requirement' is displayed to enter the valid password. "
				+ extest.addScreenCapture(Utils.captureScreenShot(driver)));

		driver.findElement(OR.NewPswd).clear();
		Utils.sleep(1000);
		Utils.scrolldown();
		Utils.entertext(OR.NewPswd, Pswd);
		Utils.entertext(OR.NewCnfrmPswd, Pswd);
		extest.log(LogStatus.INFO,
				"'Details with - User Email: " + UserEmail + ", First Name: " + UserFirstName + ", Last Name: "
						+ UserLastname + " and Password: " + Pswd + " have been entered to create an account.");

		String rowNum = testMethodData.get("rowNum");
		String sheetName = testMethodData.get("sheetName");
		ExcelTestDataUtil.setCellData(Integer.valueOf(rowNum) + 2, 4, sheetName, UserEmail);

		extest.addScreenCapture(Utils.captureScreenShot(driver));
		Utils.clickelement(OR.CreateNewAcctPg2);

		// Validating the Congratulations message after the User account is created.

		if (driver.findElement(OR.CongratsMsg).isDisplayed()) {
			extest.log(LogStatus.PASS, "Congratulations! Your account has now been created."
					+ "Message is DISPLAYED as expected" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR,
					"Congratulations! Your account has now been created." + "Message is NOT DISPLAYED as expected"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating UserName is DISPLAYED on the right top corner near the heart icon.
		String UIUserName = driver.findElement(OR.UserName).getText();
		if (UIUserName.contains(UserFirstName)) {
			extest.log(LogStatus.PASS, "User First Name '" + UserFirstName + "' is DISPLAYED as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "User Name is NOT DISPLAYED as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating the User is able to see the My Account OverView.
		if (driver.findElement(OR.MyAccountVal).isDisplayed()) {
			extest.log(LogStatus.PASS, "User is been directed to the 'My Account' Page"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.PASS, "User cannot see the Options for the My Account screen "
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Validating if the User is able to see all the options related to 'My Account.
		String myaccountoptions = testMethodData.get("MyAccountOptions");

		List<WebElement> allOptions = driver.findElements(By.xpath("//*[@id='content']/div[2]/div/ul/li"));
		int allOptionsCount = allOptions.size();

		// Validating the Expected and UI options are same.
		for (int i = 0; i < allOptionsCount; i++) {
			String optionValue = allOptions.get(i).getText();
			if (myaccountoptions.contains(optionValue)) {
				extest.log(LogStatus.PASS,
						"My Account Option -> " + "'" + optionValue + "'" + " is DISPLAYED as expected");
			} else {
				extest.log(LogStatus.ERROR,
						"My Account Option -> " + "'" + optionValue + "'" + " is NOT DISPLAYED as expected");
			}
		}
		extest.addScreenCapture(Utils.captureScreenShot(driver));

		Utils.sleep(1000);
		String ideaboardname1 = testMethodData.get("IdeaBoard1");
		String ideaboardname2 = testMethodData.get("IdeaBoard2");
		String searchItem1 = testMethodData.get("SearchItem1");
		String addNotes = testMethodData.get("AddNotes");
		Utils.entertext((OR.Search), searchItem1);
		extest.log(LogStatus.INFO,
				"Entering the search item for " + searchItem1 + " to start the Idea Board validation");
		Utils.clickelement(OR.SearchItem);
		Utils.waitForLoad(driver);
		List<WebElement> heart = driver.findElements(OR.IBcertona);
		heart.get(0).click();
		Utils.sleep(2000);
		// Creating Idea board one
		Utils.clickelement(OR.UserCreateIB);
		Utils.sleep(1000);
		Utils.entertext(OR.NewBoardName, ideaboardname1);
		Utils.clickelement(OR.SaveIB);
		Utils.sleep(4000);
		heart.get(0).click();
		Utils.sleep(2000);
		WebElement addtoIB1 = driver.findElement(By.xpath("//span[contains(text(),'" + ideaboardname1 + "')]"));
		if (addtoIB1.isDisplayed()) {
			extest.log(LogStatus.PASS, "The IdeaBoard " + ideaboardname1 + " has been CREATED"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "The IdeaBoard " + ideaboardname1 + " is NOT CREATED"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(2000);
		Utils.popUpCls();
		heart.get(1).click();
		Utils.sleep(2000);
		addtoIB1 = driver.findElement(By.xpath("//span[contains(text(),'" + ideaboardname1 + "')]"));
		addtoIB1.click();
		Utils.sleep(4000);
		heart.get(2).click();
		Utils.sleep(2000);
		// Creating Idea Board 2
		Utils.clickelement(OR.UserCreateIB);
		Utils.sleep(2000);
		Utils.entertext(OR.NewBoardName, ideaboardname2);
		Utils.clickelement(OR.SaveIB);
		Utils.sleep(4000);
		Utils.scrolldown();
		heart.get(3).click();
		WebElement addtoIB2 = driver.findElement(By.xpath("//span[contains(text(),'" + ideaboardname2 + "')]"));
		if (addtoIB2.isDisplayed()) {
			extest.log(LogStatus.PASS,
					"The second IdeaBoard " + ideaboardname2
							+ " has been CREATED and the item is added to the Idea Board"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL,
					"The second IdeaBoard " + ideaboardname2 + " is NOT CREATED to add the item to Idea Board"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		addtoIB2 = driver.findElement(By.xpath("//span[contains(text(),'" + ideaboardname2 + "')]"));
		addtoIB2.click();
		Utils.sleep(4000);
		Utils.clickelement(OR.UserName);
		Utils.sleep(2000);
		if (driver.findElement(OR.UserIBMyAccount).isDisplayed()) {
			Utils.clickelement(OR.UserIBMyAccount);
		}
		Utils.sleep(2000);
		WebElement userIB = driver.findElement(By.xpath("//*[contains(text(),'" + ideaboardname1 + "')]"));
		userIB.click();
		Utils.sleep(2000);
		// Adding notes to the product
		List<WebElement> addnotes = driver.findElements(By.xpath("//*[contains(text(),'Add Note')]"));
		addnotes.get(0).click();
		Utils.sleep(3000);
		Utils.entertext(OR.AddNotes, addNotes);
		Utils.sleep(1000);
		Utils.clickelement(OR.SaveNote);
		Utils.sleep(4000);
		WebElement addNotetitle = driver.findElement(By.xpath("//span[contains(text(),'" + addNotes + "')]"));
		if (addNotetitle.isDisplayed()) {
			extest.log(LogStatus.PASS, "Notes with " + ideaboardname2 + " has been UPDATED to the Idea Board"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "Notes with " + ideaboardname2 + " has NOT been UPDATED to the Idea Board"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Moving the products to another idea board
		Utils.sleep(2000);
		List<WebElement> ibOptions = driver.findElements(By.xpath("//*[@class='ideaBoardMore_icon']"));
		ibOptions.get(0).click();
		List<WebElement> ibMove = driver.findElements(By.xpath("//*[@class='movetxt']"));
		ibMove.get(0).click();
		WebElement movetoIB = driver.findElement(By.xpath("//span[contains(text(),'" + ideaboardname2 + "')]"));
		if (movetoIB.isDisplayed()) {
			movetoIB.click();
			Utils.sleep(2000);
			extest.log(LogStatus.PASS, "The item has been MOVED to the " + ideaboardname2 + " Idea Board"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "The item has NOT been MOVED to the " + ideaboardname2 + " Idea Board"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(2000);

		Utils.clickelement(By.xpath("//*[@class='ideaBoardIcon editIcon']"));
		Utils.sleep(2000);
		String edittitle = Utils.randomtext();
		driver.findElement(By.xpath("(//*[@id='newBoardName'])[2]")).clear();
		Utils.entertext(By.xpath("(//*[@id='newBoardName'])[2]"), edittitle);
		extest.log(LogStatus.PASS, "Idea Board name has been EDITED to " + edittitle + ""
				+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		Utils.sleep(2000);
		Utils.clickelement(OR.EditIBSave);
		Utils.sleep(4000);

		Utils.clickelement(By.xpath("//a[contains(text(),'My Idea Boards')]"));
		ibOptions = driver.findElements(By.xpath("//*[@class='ideaBoardMore_icon']"));
		ibOptions.get(1).click();
		List<WebElement> delIBs = driver.findElements(By.xpath("//*[@class='deletetxt']"));
		delIBs.get(1);
		if ((delIBs.get(1)).isEnabled()) {
			delIBs.get(1).click();
			Utils.sleep(2000);
			List<WebElement> deleteIB = driver.findElements(By.xpath("//*[@id='deleteBoardBtn']"));
			deleteIB.get(1).click();
			extest.log(LogStatus.PASS, "The IdeaBoard " + ideaboardname2 + "was DELETED"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "The IdeaBoard " + ideaboardname2 + "was NOT DELETED"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(OR.UserName)).pause(1000)
				.moveToElement(driver.findElement(OR.logOutmousehover)).click().build().perform();

	}

	// *******************************************************************************************************************************
	/*
	 * Method Title --> tc_quickview_CA ; Method Description--> This Method validates
	 * on QUICK VIEW and related options available. Author: Vandhana.S
	 * 
	 * @throws InterruptedException
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_quickview_CA() throws InterruptedException {

		// Searching for a specific item

		String userID = testMethodData.get("UserID");
		String passWord = testMethodData.get("Password");
		Utils.login(userID, passWord);
		WebElement searchFormInput = driver.findElement(OR.InputsearchItem);
		String searchitem1 = testMethodData.get("SearchItem_1");
		searchFormInput.sendKeys(searchitem1);
		extest.log(LogStatus.INFO,
				"Entering the item '" + searchitem1 + "'to check the result, DISPLAYED as per the search");

		WebElement searchButton = driver.findElement(OR.SearchItem);
		searchButton.click();
		Utils.waitForLoad(driver);
		WebElement searchresult = driver.findElement(OR.ProductName);
		String uiresults = searchresult.getAttribute("title");
		if (searchitem1.equals(uiresults)) {
			extest.log(LogStatus.PASS, "The DISPLAYED item '" + uiresults + "'is the same as the search item '"
					+ searchitem1 + "'." + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "The DISPLAYED item '" + uiresults + "'is NOT the same as the search item '"
					+ searchitem1 + "'." + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Validating the quick view access
		Utils.sleep(3000);
		Utils.clickelement(OR.QuickView);
		Utils.sleep(3000);
		WebElement qvTitle = driver.findElement(OR.ProductTitle);
		String qvDisplayedTitle = qvTitle.getText();
		if (searchitem1.equals(qvDisplayedTitle)) {
			extest.log(LogStatus.PASS,
					"The DISPLAYED item on Quick View'" + uiresults + "'is the same as the search item '" + searchitem1
							+ "'." + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR,
					"The DISPLAYED item on Quick View '" + uiresults + "'is NOT the same as the search item '"
							+ searchitem1 + "'." + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		if (driver.findElement(OR.QVProdDesc) != null) {
			extest.log(LogStatus.PASS, "'PRODUCT DESCRIPTION' is DISPLAYED on the quick view page.");
		}

		if (driver.findElement(OR.Quantity) != null) {
			extest.log(LogStatus.PASS, "'QUANTITY' selection is DISPLAYED on the quick view page.");
		}
		if (driver.findElement(OR.AddtoRegistry) != null) {
			extest.log(LogStatus.PASS, "'ADD TO REGISTRY' is DISPLAYED on the quick view page.");
		}

		if (driver.findElement(OR.AddtoCart) != null) {
			Utils.clickelement(OR.AddtoCart);
			Utils.waitForLoad(driver);
			WebElement cart = driver.findElement(OR.ProductTitleinCart);
			String cartTitle = cart.getText();
			if (searchitem1.equals(cartTitle)) {
				extest.log(LogStatus.PASS,
						"'ADD TO CART' is DISPLAYED and User is navigated to the item cart summary, and the product title"
								+ cartTitle + " is the SAME as searched item."
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
			if (driver.findElement(OR.ViewCart) != null) {
				extest.log(LogStatus.PASS, "'VIEW CART' is DISPLAYED on the quick modal page.");
			}
			if (driver.findElement(OR.KeepShopping) != null) {
				driver.findElement(OR.KeepShopping).click();
				Utils.sleep(3000);
				extest.log(LogStatus.PASS, "'KEEP SHOPPING' is DISPLAYED on the quick modal page.");
			}
			extest.log(LogStatus.PASS, "Quick View Modal page is DISPLAYED as expected ");
		} else {
			extest.log(LogStatus.FAIL, "Quick View Modal page is NOT DISPLAYED as expected ");
		}

		// Validate the code here for the registry
		Utils.clickelement(OR.QuickView);
		Utils.waitForLoad(driver);
		Utils.clickelement(OR.AddtoRegistry);
		Utils.sleep(1000);
		
		if (Utils.isElementFound(OR.ProductRegTitle)) {
			WebElement registry = driver.findElement(OR.ProductRegTitle);
			String registryTitle = registry.getText();
			if (searchitem1.equals(registryTitle)) {
				extest.log(LogStatus.PASS,
						"'Add to cart' is DISPLAYED and User is navigated to the item cart summary, and the product title"
								+ registryTitle + " is the SAME as searched item."
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
			
			if ((Utils.isElementFound(OR.QVKeepShopping)&&(Utils.isElementFound(OR.ViewRegistry)))){
				driver.findElement(OR.QVKeepShopping).click();
				Utils.sleep(2000);
				extest.log(LogStatus.PASS, "'KEEP SHOPPING' & 'VIEW REGISTRY' is DISPLAYED on the quick modal page.");
			}
		}

		Utils.clickelement(OR.QuickView);
		Utils.waitForLoad(driver);
		if (Utils.isElementFound(By.xpath("//*[@id='saveToBoardLink']"))) {
			Utils.clickelement(By.xpath("//*[@id='saveToBoardLink']"));
			Utils.waitForLoad(driver);
			if (Utils.isElementFound(By.xpath("//a[@class='noline']"))) {
				extest.log(LogStatus.PASS,
						"'ADD TO IDEA BOARD' is DISPLAYED as expected and User is able to add the item to the Idea Board"
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
			Utils.sleep(4000);
			List<WebElement> closebtn = driver.findElements(OR.Clsmodal);
			for (int i = 0; i < closebtn.size(); i++) {
				if ((closebtn.get(i)).isDisplayed()) {
					(closebtn.get(i)).click();
				}
			}

		} else {
			extest.log(LogStatus.FAIL, "'Idea Board' is NOT DISPLAYED on the quick modal page as expected.");
		}

		Utils.clickelement(OR.QuickView);
		Utils.waitForLoad(driver);

		if (Utils.isElementFound(By.xpath("//*[contains(text(),'Find In Store')]"))) {
			Utils.clickelement(By.xpath("//*[contains(text(),'Find In Store')]"));
			Utils.sleep(2000);
			if (Utils.isElementFound(By.xpath("//*[@id='txtStoreZip']"))
					&& (Utils.isElementFound(By.xpath("//*[@id='txtStoreAddress']")))
					&& (Utils.isElementFound(By.xpath("//*[@id='txtStoreCity']")))
					&& (Utils.isElementFound(By.xpath("//*[@id='txtStoreState']")))
					&& (Utils.isElementFound(By.xpath("//*[@id='selRadius']")))
					&& (Utils.isElementFound(By.xpath("//span[contains(text(),'Go')]")))
					&& (Utils.isElementFound(By.xpath("//span[contains(text(),'Cancel')]")))) {
				extest.log(LogStatus.PASS,
						"'FIND IN STORE' Modal page is DISPLAYED as expected and User can see the options for Zip code, Address, City, State and Radius"
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			} else {
				extest.log(LogStatus.FAIL,
						"'FIND IN STORE' Modal page is DISPLAYED as expected and User can see the options for Zip code, Address, City, State and Radius"
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
			Utils.clickelement(By.xpath("//span[contains(text(),'Cancel')]"));
		}

		List<WebElement> certona = driver.findElements(By.xpath("//*[@class='carousel clearfix']"));
		if (certona.listIterator() != null) {
			extest.log(LogStatus.PASS, "'CERTONA' container is DISPLAYED as expected on the Quick view modal"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "'CERTONA' container is DISPLAYED as expected on the Quick view modal"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

	}

	// *******************************************************************************************************************************
	/*
	 * Method Title: tc_PLP_PDP_CA; Method Description: This Method validates on search
	 * option to validate the user is able to see the search related items. Author:
	 * Vandhana.S
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_PLP_PDP_CA() {

		// Getting the no of PLP and PDPs to be validated.
		int noOfPLPPDPs = Double.valueOf(testMethodData.get("NoOfPLPPDPs")).intValue();

		for (int i = 3; i <= noOfPLPPDPs; i++) {

			Utils.scrollup();
			Actions action = new Actions(driver);
			driver.findElement(OR.Products).click();
			Utils.sleep(1000);
			action.pause(1000)
					.moveToElement(
							driver.findElement(By.xpath("//*[@id='collegeBridalArea']/div[1]/div/ul/li[" + i + "]/a")))
					.pause(1000)
					.moveToElement(driver.findElement(By.xpath(
							"//*[@id='collegeBridalArea']/div[1]/div/ul/li[" + i + "]/div/div[1]/ul[1]/li[2]/a")))
					.pause(1000).click().build().perform();

			Utils.waitForLoad(driver);

			if (Utils.isElementFound(By.xpath("//*[@id='row1']/div[1]"))) {
				extest.log(LogStatus.PASS, "First Row and Column is DISPLAYED AS EXPECTED");
			} else {
				extest.log(LogStatus.ERROR, "First Row and Column is NOT DISPLAYED AS EXPECTED");
			}

			if (Utils.isElementFound(By.xpath("//*[@id='row1']/div[2]"))) {
				extest.log(LogStatus.PASS, "Second Row and Column is DISPLAYED AS EXPECTED");
			} else {
				extest.log(LogStatus.ERROR, "Second Row and Column is NOT DISPLAYED AS EXPECTED");
			}

			if (Utils.isElementFound(By.xpath("//*[@id='row1']/div[3]"))) {
				extest.log(LogStatus.PASS, "Third Row and Column is DISPLAYED AS EXPECTED");
			} else {
				extest.log(LogStatus.ERROR, "Third Row and Column is NOT DISPLAYED AS EXPECTED");
			}

			String productTitle = "";
			if (Utils.isElementFound(By.xpath("//*[@id='row1']/div[1]/div[2]/div[3]/div[1]/a"))) {
				WebElement titleElement = driver.findElement(By.xpath("//*[@id='row1']/div[1]/div[2]/div[3]/div[1]/a"));
				productTitle = titleElement.getText();
				extest.log(LogStatus.INFO,
						"The item " + productTitle + "has been selected in PLP screen to be navigated to PDP screen"
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
				titleElement.click();
				Utils.waitForLoad(driver);

				WebElement proTitleElement = driver.findElement(By.xpath("//*[@id='productTitle']"));
				String displayedTitle = proTitleElement.getText();
				if (productTitle.equalsIgnoreCase(displayedTitle)) {
					extest.log(LogStatus.PASS,
							"The item displayed " + displayedTitle + " is the same as Selected in PLP screen."
									+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
				} else {
					extest.log(LogStatus.FAIL,
							"The item displayed " + displayedTitle + " is NOT the same as Selected in PLP screen."
									+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
				}

				By prodView = By.xpath("//*[@id='prodViewDefault-tab1']/a");
				// Utils.scrolldown(1600);
				Utils.scrolldown();
				if (Utils.isElementFound(prodView)) {
					extest.log(LogStatus.PASS, "'Product Information' is DISPLAYED as expected ");
				} else {
					extest.log(LogStatus.ERROR, "'Product Information' is NOT DISPLAYED as expected ");
				}

				By ratingView = By.xpath("//*[@id='prodViewDefault-tab2']/a");
				if (Utils.isElementFound(ratingView)) {
					extest.log(LogStatus.PASS, "'Ratings & Review' is DISPLAYED as expected ");
				} else {
					extest.log(LogStatus.ERROR, "'Ratings & Review' is NOT DISPLAYED as expected ");
				}
			}

			if (Utils.isElementFound(OR.Chooseitemsbelow)) {
				Utils.clickelement(OR.Chooseitemsbelow);
				Utils.sleep(1000);

				if (driver.findElement(By.xpath("//input[@name='qty']")).isDisplayed()) {
					extest.log(LogStatus.PASS, "'QUANTITY' selection is DISPLAYED on the quick view page.");
				}
				if (driver.findElement(OR.AddtoRegistry).isDisplayed()) {
					extest.log(LogStatus.PASS, "'ADD TO REGISTRY' is DISPLAYED on the quick view page.");
				}

				if (driver.findElement(OR.AddtoCart).isDisplayed()) {
					extest.log(LogStatus.PASS, "'ADD TO CART' is DISPLAYED on the quick view page.");
				}
			}

			if (Utils.isElementFound(OR.Quantity)) {
				if (driver.findElement(OR.Quantity).isDisplayed()) {
					extest.log(LogStatus.PASS, "'QUANTITY' selection is DISPLAYED on the quick view page.");
				}
				if (driver.findElement(OR.AddtoRegistry).isDisplayed()) {
					extest.log(LogStatus.PASS, "'ADD TO REGISTRY' is DISPLAYED on the quick view page.");
				}

				if (driver.findElement(OR.AddtoCart).isDisplayed()) {
					extest.log(LogStatus.PASS, "'ADD TO CART' is DISPLAYED on the quick view page.");
				}
				if (driver.findElement(OR.PDPIdeaBoard).isDisplayed()) {
					extest.log(LogStatus.PASS, "'ADD TO IDEA BOARD' is DISPLAYED on the quick view page.");
				}
			}
		
		}
		

	}

	// *******************************************************************************************************************************
	/*
	 * Method Title: tc_sortFilter_CA; Method Description: This Method validates on
	 * sort and filter options as well as the bread crumb. Author: Vandhana.S
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_sortFilter_CA() {
		// Clicking on the Kitchen L1 and Navigating to PLP screen to validations
		driver.findElement(OR.Products).click();
		Utils.sleep(2000);

		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("(//*[contains(text(),'Kitchen')])[2]")))
		.pause(1000)
				.moveToElement(driver.findElement(By.xpath("(//*[contains(text(),'Blenders')])[1]")))
				.pause(1000)
				.click().build()
				.perform();

		// Validating on the Bread crumb
		if (Utils.isElementFound(By.xpath("//*[@id='subHeader']/div[1]/div/div"))) {
			extest.log(LogStatus.PASS,
					"'Bread Crumb' Home -> Kitchen -> Small Appliances -> Blenders is DISPLAYED as expected"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR,
					"'Bread Crumb' Home-> Kitchen -> Small Appliances -> Blenders is DISPLAYED as expected"
							+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(4000);
		Utils.waitForLoad(driver);
		// Validating on the List View of the products.
		WebElement gridList = driver.findElement(By.xpath("//*[@title='List View']"));
		gridList.click();
		Utils.waitForLoad(driver);
		Utils.sleep(2000);
		if ((driver.findElement(By.xpath("//*[@class='prodListRow clearfix noMar']"))).isDisplayed()) {
			extest.log(LogStatus.PASS, "'List View Validation'--> data is DISPLAYED in a List view as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "'List View Validation'--> data is NOT DISPLAYED in a List View as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating on the 3 Grid View of the products.
		WebElement grid3 = driver.findElement(By.xpath("//*[@title='Product Grid View - 3 Across']"));
		grid3.click();
		Utils.waitForLoad(driver);
		Utils.sleep(2000);
		if ((driver.findElement(By.xpath("//*[@class='grid_9 noMar grid_3']"))).isDisplayed()) {
			extest.log(LogStatus.PASS, "'3 Grid Validation'--> data is DISPLAYED in 3 columns as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "'3 Grid Validation'--> data is NOT DISPLAYED in 3 columns as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		// Validating on the 4 Grid View of the products.
		WebElement grid4 = driver.findElement(By.xpath("//*[@title='Product Grid View - 4 Across']"));
		grid4.click();
		Utils.waitForLoad(driver);
		Utils.sleep(2000);
		if ((driver.findElement(By.xpath("//*[@class='grid_9 noMar ']"))).isDisplayed()) {
			extest.log(LogStatus.PASS, "'4 Grid Validation'--> data is DISPLAYED in 4 columns as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "'4 Grid Validation'--> data is NOT DISPLAYED in 4 columns as expected"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Validating on the Sort Order
		WebElement selectsort = driver.findElement(By.id("pagSortOpt"));
		selectsort.click();
		// validating price low to high
		Utils.sleep(1000);
		new Select(selectsort).selectByVisibleText("Price - low to high");
		Utils.sleep(2000);
		List<WebElement> pricediff = driver.findElements(By.xpath("//*[@class='isPrice']"));
		WebElement firstitemprice = pricediff.get(0);
		String itemprice1 = firstitemprice.getText();
		itemprice1 = itemprice1.replace("$", "");
		itemprice1 = itemprice1.replace(" ", "");
		itemprice1 = itemprice1.replace(",", "");
		itemprice1 = itemprice1.replace("Each", "");
		WebElement seconditemprice = pricediff.get(1);
		String itemprice2 = seconditemprice.getText();
		itemprice2 = itemprice2.replace("$", "");
		itemprice2 = itemprice2.replace(" ", "");
		itemprice2 = itemprice2.replace(",", "");
		itemprice2 = itemprice2.replace("Each", "");
		double ip1 = 0;
		double ip2 = 0;
		if (itemprice1.contains("-")) {
			String[] itemprice1Array = itemprice1.split("-");
			String price1 = itemprice1Array[0];

			ip1 = Double.valueOf(price1);
		} else {
			ip1 = Double.valueOf(itemprice1);
		}
		if (itemprice2.contains("-")) {
			String[] itemprice2Array = itemprice2.split("-");
			String price2 = itemprice2Array[0];
			price2.replace("$", "");
			ip2 = Double.valueOf(price2);

		} else {
			ip2 = Double.valueOf(itemprice2);
		}
		// comparing the first and second price of the products
		if (ip1 <= ip2) {

			extest.log(LogStatus.PASS, "First item price'" + ip1 + "' is LOWER or equal to the Second item price'" + ip2 + "'"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "First item price'" + ip1 + "' is NOT LOWER than Second item price '" + ip2
					+ "'" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// validating the Price High To Low
		selectsort = driver.findElement(By.id("pagSortOpt"));
		selectsort.click();
		// validating price high to low
		Utils.sleep(1000);
		new Select(selectsort).selectByVisibleText("Price - high to low");
		Utils.sleep(2000);
		List<WebElement> pricediffs = driver.findElements(By.xpath("//*[@class='isPrice']"));
		WebElement firstIprice = pricediffs.get(0);
		String itemPrice3 = firstIprice.getText();
		itemPrice3 = itemPrice3.replace("$", "");
		itemPrice3 = itemPrice3.replace(" ", "");
		itemPrice3 = itemPrice3.replace(",", "");
		itemPrice3 = itemPrice3.replace("Each", "");
		WebElement secondIprice = pricediffs.get(1);
		String itemPrice4 = secondIprice.getText();
		itemPrice4 = itemPrice4.replace("$", "");
		itemPrice4 = itemPrice4.replace(" ", "");
		itemPrice4 = itemPrice4.replace(",", "");
		itemPrice4 = itemPrice4.replace("Each", "");
		double IP3 = 0;
		double IP4 = 0;
		System.out.println(itemPrice3);
		if (itemPrice3.contains("-")) {
			String[] itemprice1Array = itemPrice3.split("-");
			String price3 = itemprice1Array[0];

			IP3 = Double.valueOf(price3);
		} else {
			IP3 = Double.valueOf(itemPrice3);
		}
		if (itemPrice4.contains("-")) {
			String[] itemprice2Array = itemPrice4.split("-");
			String price4 = itemprice2Array[0];
			price4.replace("$", "");
			IP4 = Double.valueOf(price4);

		} else {
			IP4 = Double.valueOf(itemPrice4);
		}
		// comparing the first and second price of the products
		if (IP3 >= IP4) {

			extest.log(LogStatus.PASS, "First item price'" + IP3 + "' is HIGHER or Equal to Second item price'" + IP4
					+ "'" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "First item price'" + IP3 + "' is NOT HIGHER than Second item price '" + IP4
					+ "'" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// validating on the Facets --> Brand and Price as these are common for every
		// product
		// ----> Pending
		/*
		 * Utils.scrolldown(); if (Utils.isElementFound(OR.Brandfilter)) {
		 * extest.log(LogStatus.PASS,
		 * "Facet for Brand is DISPLAYED as exepected to narrow the selection by Brand"
		 * ); }
		 */

	}

	// *******************************************************************************************************************************
	/*
	 * Method Title: tc_compareProducts_CA; Method Description: This Method validates
	 * on the comparison of the products. Author: Vandhana.S
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_compareProducts_CA() {

		// hovering the mouse to select the Products
		driver.findElement(OR.Products).click();
		Utils.sleep(2000);
		
		WebElement l1item = driver.findElement(OR.DiningCA);
						Actions action = new Actions(driver);
				action.moveToElement(l1item).pause(1000)
						.moveToElement(driver.findElement(OR.CakesDesserts)).pause(1000).click().build().perform();
				Utils.waitForLoad(driver);

			
				
			
		Utils.sleep(3000);
		if (Utils.isElementFound(OR.L3Header)) {
			extest.log(LogStatus.PASS, "Selection of the 'Products' has been made for the comparision."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.ERROR, "Selection of the 'Products' was NOT made for the comparision."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(2000);
		// collecting the check boxes for 1st and 2nd products
		List<WebElement> chkbx = driver.findElements(OR.Comparechkbx);
		for (int i = 0; i <= 1; i++) {
			@SuppressWarnings("unused")
			boolean schkbx = false;
			schkbx = chkbx.get(i).isSelected();
			if (schkbx = true) {
				chkbx.get(i).click();
				Utils.sleep(2000);
				int product = i + 1;
				extest.log(LogStatus.PASS, "Selected " + product + " to compare"
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
				Utils.sleep(2000);
			}
		}

		Utils.sleep(2000);
		// Validating the compare drawer
		WebElement CompareDrawer = driver.findElement(OR.CompareDrawer);
		if (CompareDrawer.isDisplayed()) {
			extest.log(LogStatus.PASS, "Compare Drawer is visible after adding the product to compare"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "Compare Drawer is NOT visible after adding the product to compare."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.clickelement(OR.CompareProducts);
		Utils.sleep(3000);

		if (Utils.isElementFound(OR.AddtoCart)) {

			if (driver.findElement(OR.AddtoRegistry).isDisplayed()) {
				extest.log(LogStatus.PASS, "'ADD TO REGISTRY' is DISPLAYED on the quick view page.");
			}

			if (driver.findElement(OR.AddtoCart).isDisplayed()) {
				extest.log(LogStatus.PASS, "'ADD TO Cart' is DISPLAYED on the quick view page.");
			}
			if (driver.findElement(OR.Comparefindinstore).isDisplayed()) {
				extest.log(LogStatus.PASS, "'ADD TO IDEA BOARD' is DISPLAYED on the quick view page.");
			}
		}

		extest.log(LogStatus.PASS, "List of Products added to Compare are visible in the Compare screen"
				+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		Utils.clickelement(OR.AddAnotherItem);
		Utils.sleep(2000);
		// adding the third item to the compare
		Utils.clickelement(OR.ThirdItem);
		Utils.sleep(3000);
		extest.log(LogStatus.PASS,
				"Selected " + 3 + " product to compare." + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		Utils.clickelement(OR.CompareProducts);
		Utils.sleep(2000);
		extest.log(LogStatus.PASS,
				"List of products to compare are visible in the Compare screen with the choose options to select."
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		Utils.clickelement(OR.AddAnotherItmBck);
		Utils.sleep(3000);
		Utils.clickelement(OR.RemoveAll);
		Utils.sleep(2000);
		extest.log(LogStatus.PASS,
				"After clicking on the Remove All button the Compare Drawer does not have any items to compare.");

		WebElement CompareDrawer1 = driver.findElement(OR.CompareDrawer);
		if (CompareDrawer1.isDisplayed()) {
			extest.log(LogStatus.FAIL, "Compare Drawer is still visible even after removing all the Products."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.PASS, "Compare Drawer is NOT visible as expected after removing the all the Products."
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
	}

	// *******************************************************************************************************************************
	/*
	 * Method Title: tc_LTL_Assembly_CA; Method Description: This Method validates on
	 * Truck delivery, Assembly options. Author: Vandhana.S
	 */
	// ********************************************************************************************************************************
	public void tc_LTL_Assembly_CA() {

		// Validating the Truck Load
		WebElement searchFormInput = driver.findElement(OR.InputsearchItem);
		String searchitem = testMethodData.get("SearchItem");
		searchFormInput.sendKeys(searchitem);
		extest.log(LogStatus.INFO, "Entering the SKU '" + searchitem + "' to validate the Truck Develivery option");

		WebElement searchButton = driver.findElement(OR.SearchItem);
		searchButton.click();
		Utils.waitForLoad(driver);
		WebElement searchresult = driver.findElement(OR.ProductName);
		String uiresults = searchresult.getAttribute("title");
		if (searchresult.isDisplayed()) {
			extest.log(LogStatus.PASS, " " + uiresults + " is DISPLAYED as result of the searched item"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, " " + uiresults + " is NOT DISPLAYED as result of the searched item"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(3000);
		searchresult.click();
		Utils.waitForLoad(driver);
		WebElement truckdelopt = driver.findElement(OR.TruckDeliveryOption);
		if (truckdelopt.isDisplayed()) {
			extest.log(LogStatus.PASS, "Truck delivery option is VISIBLE for the searched item"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "Truck delivery option is NOT VISIBLE for the searched item"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		WebElement selectdeloption = driver.findElement(OR.SelectDelOption);
		selectdeloption.click();
		Utils.sleep(2000);
		String deliveryoption = testMethodData.get("DeliveryOption");
		Utils.clickelement(By.xpath("//a[contains(text(),'" + deliveryoption + "')]"));
		Utils.sleep(2000);
		WebElement slctporch = driver.findElement(OR.SelectPorch);
		if (slctporch.isEnabled()) {
			slctporch.click();
			extest.log(LogStatus.PASS, "Assembly option is VISIBLE for the searched item"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "Assembly option is NOT VISIBLE for the searched item"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.sleep(2000);
		String porchzipcode = testMethodData.get("ZipCode");
		if (Utils.isElementFound(OR.PorchZipcode)) {
			Utils.sleep(2000);
			Utils.entertext(OR.PorchZipcode, porchzipcode);
			driver.findElement(OR.PorchZipcode).clear();
			Utils.sleep(2000);
			Utils.entertext(OR.PorchZipcode, porchzipcode);
			Utils.sleep(2000);
			WebElement noOfPieces = driver.findElement(By.xpath("//label[@for='radio-0']/div"));
			String estprice = noOfPieces.getText();
			driver.findElement(By.xpath("//label[@for='radio-0']")).click();
			extest.log(LogStatus.INFO, "Available installation charges are DISPLAYED "
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			Utils.clickelement(By.xpath("//*[@class='porchButton']"));
			Utils.sleep(2000);
			WebElement estpdppriceis = driver.findElement(By.xpath("//span[@class='serviceEstPrice']"));
			String estpdpprice = estpdppriceis.getText();
			if (estpdpprice.contains(estprice)) {
				extest.log(LogStatus.PASS, "Assembly charges are DISPLAYED as SELECTED"
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			} else {
				extest.log(LogStatus.FAIL, "Assembly charges are NOT DISPLAYED as SELECTED "
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
		}
		Utils.clickelement(OR.AddtoCart);
		Utils.sleep(2000);
		Utils.isElementFound(OR.CartSummary);
		if ((driver.findElement(OR.CartSummary).isDisplayed())) {
			extest.log(LogStatus.PASS,
					"Cart Summary is DISPLAYED as expected" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL,
					"Cart Summary is DISPLAYED as expected" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		Utils.clickelement(OR.KeepShopping);
		Utils.scrollup();

	}

	// ******************************************************************************************************************************
	/*
	 * Method Title: tc_ropis_CA; Method Description: This Method validates on the buy
	 * online and pick up instore items. Author: Vandhana.S
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_ropis_CA() {

		// Searching the item to validate on the ropis
		WebElement searchFormInput = driver.findElement(OR.InputsearchItem);
		String searchitem = testMethodData.get("SKU");
		searchFormInput.sendKeys(searchitem);
		extest.log(LogStatus.INFO, "Entering the SKU '" + searchitem + "'to validate the Truck Develivery option");

		WebElement searchButton = driver.findElement(OR.SearchItem);
		searchButton.click();
		WebElement searchresult = driver.findElement(OR.ProductName);
		String uiresults = searchresult.getAttribute("title");
		if (searchresult.isDisplayed()) {
			extest.log(LogStatus.PASS, " " + uiresults + " is DISPLAYED as result of the searched item"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, " " + uiresults + " is NOT DISPLAYED as result of the searched item"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		
		Utils.clickelement(OR.ProductName);
		Utils.clickelement(OR.FindInStoreCA);
		String ZipCode = testMethodData.get("ZipCode");
		Utils.entertext(OR.EnterZIPCA, ZipCode);
		Utils.sleep(1000);
		Utils.clickelement(OR.FindStore);
		Utils.sleep(3000);
		Utils.clickelement(OR.ReserveNowCA);
		if (Utils.isElementFound(By.xpath("//*[@class='addCartModalCheckout']"))) {
			extest.log(LogStatus.PASS, "Reserve Online and Pick Up in Store is available"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else if (Utils.isElementFound(By.xpath("//*[@id='dialoghead']"))) {
			extest.log(LogStatus.ERROR,
					"ropis functionality is turned off" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}		
	}

	// *******************************************************************************************************************************
	/*
	 * Method Title: tc_shopbyBrand_CA; Method Description: This Method validates
	 * on the comparison of the products. Author: Vandhana.S
	 */
	// ********************************************************************************************************************************
	@Test
	public void tc_shopbyBrand_CA() {

		// Selecting the products to shop by Brand
		Utils.clickelement(OR.Products);
		Utils.sleep(1000);
		extest.log(LogStatus.INFO,
				"Selecting 'Shop by Brand'" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		Utils.clickelement(OR.ShopbyBrand);
		Utils.sleep(3000);
		if (Utils.isElementFound(OR.BrandsPage) && (Utils.isElementFound(OR.ShopOurBrandstitle))) {
			extest.log(LogStatus.PASS,
					"Page with list of Brands is DISPLAYED" + extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "Page with list of Brands is NOT DISPLAYED"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}

		// Selecting the brand letter to validate on the list of brands displayed for
		// that selection.
		Utils.sleep(2000);
		String brandlettersel = testMethodData.get("BrandL");
		WebElement brandletter = driver.findElement(By.xpath("//*[@href='#brandChar" + brandlettersel + "']"));
		brandletter.click();
		Utils.sleep(2000);
		String selectBrand = testMethodData.get("DesiredBrand");
		extest.log(LogStatus.INFO, "Desired Brand name is '" + selectBrand + "'");
		WebElement uiBrand = driver.findElement(By.xpath("//*[@title='" + selectBrand + "']"));
		if (uiBrand.isDisplayed()) {
			extest.log(LogStatus.PASS, "Brand is DISPLAYED as per the user selection"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		} else {
			extest.log(LogStatus.FAIL, "Brand is NOT DISPLAYED as per the user selection"
					+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
		}
		uiBrand.click();
		List<WebElement> products = driver.findElements(OR.ProductName);
		for (int i = 0; i <= 3; i++) {
			WebElement productname = products.get(i);
			String productTitle = productname.getText();
			if (productTitle.contains(selectBrand)) {
				extest.log(LogStatus.PASS,
						"Displayed product name '" + productTitle + "' is the same as the DESIRED Brand name"
								+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			} else {
				extest.log(LogStatus.FAIL, "Brand is NOT DISPLAYED as per the user selection"
						+ extest.addScreenCapture(Utils.captureScreenShot(driver)));
			}
		}

	}

}
