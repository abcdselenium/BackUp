package com.bbb.util;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.bbb.AbstractTestCases;
import com.bbb.repository.OR;

public final class Utils {
	static WebDriver driver = null;
	// To Launch the Browser

	public static WebDriver getBrowser(String browserName) {

		if ("chrome".equalsIgnoreCase(browserName)) {
			System.setProperty("webdriver.chrome.driver", "C:\\Drivers\\chromedriver.exe");
			ChromeOptions options = new ChromeOptions();
			options.setBinary("C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe");
			options.addArguments("disable-infobars");
			options.addArguments("-incognito");
			driver = new ChromeDriver(options);
		} else if ("firefox".equalsIgnoreCase(browserName)) {
			System.setProperty("webdriver.gecko.driver", "C:\\Drivers\\geckodriver.exe");
			FirefoxOptions firefoxOptions = new FirefoxOptions();
			firefoxOptions.setBinary("C:\\Program Files\\Mozilla Firefox\\firefox.exe");
			firefoxOptions.setAcceptInsecureCerts(true);
			driver = new FirefoxDriver(firefoxOptions);
		}

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		return driver;
	}

	// To Open the Launch the URL and navigate to the URL
	public static void openUrl(WebDriver driver, String url) {
		driver.navigate().to(url);
	}

	// Waiting for the driver to load
	public static void waitForLoad(WebDriver driver) {
		ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
			}
		};
		WebDriverWait wait = new WebDriverWait(driver, 5);
		wait.until(pageLoadCondition);
	}

	// To capture the screenshots
	public static String captureScreenShot(WebDriver ldriver) {
		String fn = System.currentTimeMillis() + ".png";
		try {
			File src = ((TakesScreenshot) ldriver).getScreenshotAs(OutputType.FILE);
			File f = new File(AbstractTestCases.dirName + System.getProperty("file.separator") + fn);
			FileUtils.copyFile(src, f);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return fn;
	}

	// To enter the text in the text fields
	public static void entertext(By locator, String text) {
		try {
			WebElement element = driver.findElement(locator);
			element.click();
			element.sendKeys(text);
			} catch (NoSuchElementException e) {
			System.err.format("No Element Found to enter text" + e);
		}
	}

	// To click on an element
	public static void clickelement(By locator) {
		try {
			WebElement element = driver.findElement(locator);
			element.click();
		} catch (NoSuchElementException e) {
			System.err.format("No Element Found to click" + e);
		}
	}

	// To wait
	public static void sleep(int seconds) {
		try {
			Thread.sleep(seconds);
		} catch (InterruptedException e) {
		}
	}

	// To select the element for a check box
	public static void selectelement(By locator) {
		try {
			WebElement element = driver.findElement(locator);
			if (element.isSelected()) {
				element.click();
			}
		} catch (NoSuchElementException e) {
			System.err.format("No Element Found to click" + e);
		}

	}

	// To generate a random name
	public static String random() {
		Random randomGenerator = new Random();
		int randomInt = randomGenerator.nextInt(9000);
		return "AutoUser" + randomInt + "@gmail.com";
	}

	//To generate random String
	public static String randomtext() {
		Random randomGenerator = new Random();
		int randomInt = randomGenerator.nextInt(9000);
		return "Random" + randomInt;
	}
	
	
	// To verify if the element is found
	public static boolean isElementFound(By element) {
		try {
			if (driver.findElement(element) != null) {
				return true;
			}
		} catch (NoSuchElementException e) {
		}
		return false;
	}

	// To scroll the mouse down
	public static void scrolldown() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("scroll(0, 450)");
	}

	public static void scrolldown(int y) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("scroll(0, " + y + ")");
	}

	// To scroll the mouse up
	public static void scrollup() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("scroll(0, -450)");
	}

	public static void scrollup(int y) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("scroll(0, " + y + ")");
	}
	// This will scroll the page till the element is found
	public static void scrollToElement(By element) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].scrollIntoView();", element);
	}

	/***********************************************************************************************************************
	 * 
	 * --------> BELOW METHODS ARE THE GENERIC METHODS RELATED TO THE APPLICATION
	 * <--------
	 * 
	 ***********************************************************************************************************************/

	// Creating a new account
	public static String tc_newUAccount() {
		Utils.clickelement(OR.SignIn);
		Utils.sleep(3000);
		String UserEmail = Utils.random();
		Utils.entertext(OR.NewEmailID, UserEmail);
		Utils.clickelement(OR.CreateNewAcctPg1);
		Utils.sleep(1000);
		String UserFirstName = "BedBath";
		String UserLastname = "Beyond";
		String Pswd = "Auto@1234";
		Utils.entertext(OR.FirstName, UserFirstName);
		Utils.entertext(OR.LastName, UserLastname);
		Utils.sleep(1000);
		Utils.scrolldown();
		Utils.entertext(OR.NewPswd, Pswd);
		Utils.entertext(OR.NewCnfrmPswd, Pswd);
		Utils.clickelement(OR.CreateNewAcctPg2);
		Utils.sleep(2000);
		return UserEmail;
	}

	// To close the pop up window
	public static void popUpWndw1() throws InterruptedException {

		if(Utils.isElementFound(OR.PopUpWndw1)) {
		Utils.waitForLoad(driver);
		Utils.sleep(5000);
		List<WebElement> popupwindow = driver.findElements(OR.PopUpWndw1);
		if (popupwindow.size() != 0) {
			for(int i=0; i<= popupwindow.size();i++ ) {
				if(popupwindow.get(i).isEnabled()) {
					popupwindow.get(i).click();
					}
				}					
			} 
		}
	}
	
	// To close the pop up window
		public static void popUpWndw2() throws InterruptedException {

		if(Utils.isElementFound(OR.PopUpWndw2)) {
			Utils.waitForLoad(driver);
			Utils.sleep(5000);
			List<WebElement> popupwindow = driver.findElements(OR.PopUpWndw2);
				if (popupwindow.size() != 0) {
					for(int i=0; i<= popupwindow.size();i++ ) {
						if(popupwindow.get(i).isEnabled()) {
							popupwindow.get(i).click();
						}
					}					
				} 
			}
		}

	
	//Logging into the application
		public static void login(String UserID, String Password)
		{
			Utils.clickelement(OR.SignIn);
			Utils.clickelement(OR.UserID);
			Utils.entertext(OR.UserID, UserID);
			Utils.clickelement(OR.Password);
			Utils.entertext(OR.Password, Password);
			Utils.clickelement(OR.SignInBtn);
			Utils.waitForLoad(driver);
			
		}

	// Logging out of the application
	public static void logOut() {
		
		List<WebElement> logouts = driver.findElements(By.xpath("//*[contains(text(),'Log Out')]"));
		int logOut = logouts.size();
		for (int i=0; i<logOut; i++) {
			if (logouts.get(i).isDisplayed()) {
				logouts.get(i).click();
			}
		}
		

	}
	
	public static void popUpCls() {
		List<WebElement> popups = driver.findElements(By.xpath("//*[@class='ui-dialog-titlebar-close ui-corner-all']"));
		int popup = popups.size();
		for (int i=0; i<popup; i++) {
			if (popups.get(i).isDisplayed()) {
				popups.get(i).click();
			}
		}
		

	}
	
	public static void selectcolor() {
		if (driver.findElement(OR.Color) != null) {
			List<WebElement> colors = driver.findElements(OR.Color);
			colors.get(1).click();
			}
		
	}

}
