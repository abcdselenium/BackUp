package com.bbb;

import java.io.File;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.bbb.util.ExcelTestDataUtil;
import com.bbb.util.Utils;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public abstract class AbstractTestCases {

	public WebDriver driver;
	public ExtentTest extest;
	public ExtentReports exReport;
	public String methodName;
	
	public static String extentReport;
	public static String dirName;

	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MMM_dd_HH_mm");
	public static Map<String, Map<String, String>> excelData = new HashMap<String, Map<String, String>>();
	
	public Map<String, String> testMethodData = new HashMap<String, String>();

	@BeforeSuite
	public void beforeSuite() {
		// extentReport = "report_" + sdf.format(new Date()) + ".html";
		String dirName = sdf.format(new Date());
		File f = new File(dirName);
		f.mkdir();
		AbstractTestCases.dirName = dirName;
		AbstractTestCases.extentReport = dirName + System.getProperty("file.separator") + "report_" + dirName + ".html";
	}

	@BeforeMethod
	public void beforeMethod(Method method) {
		String mName = method.getName();
		testMethodData = excelData.get(mName);
		driver = Utils.getBrowser(testMethodData.get("browser"));
		extest = exReport.startTest(mName);
		String url = testMethodData.get("url"); 
		if(url != null) {
			extest.log(LogStatus.INFO, "Loading the URL: " + url.trim());
			Utils.openUrl(driver, url.trim());
			Utils.waitForLoad(driver);
			extest.log(LogStatus.PASS, "Page loaded successfully.");
			extest.addScreenCapture(Utils.captureScreenShot(driver));
		}
	}

	@AfterMethod
	public void afterMethod(ITestResult result) throws Exception {
		String rowNum = testMethodData.get("rowNum");
		String sheetName = testMethodData.get("sheetName");
		if (result.getStatus() == ITestResult.FAILURE) {
			extest.log(LogStatus.FAIL, "Test Case Failed");
			ExcelTestDataUtil.setCellData(Integer.valueOf(rowNum), 2, sheetName, "FAIL");
		}else {
			ExcelTestDataUtil.setCellData(Integer.valueOf(rowNum), 2, sheetName, "PASS");
		}
		driver.quit();
	}

	@BeforeTest
	public void beforeTest() {
		exReport = new ExtentReports(extentReport, false);
	}

	@AfterTest
	public void afterTest() {
		exReport.endTest(extest);
		exReport.flush();
	}

}
