package com.bbb.repository;

import org.openqa.selenium.By;

public class OR {
	
//Objects related to create account and Signing in to the application.
	public static final By SignIn = By.xpath("//a[@href='/store/account/Login']");	
	public static final By UserID = By.id("email");
	public static final By Password = By.id("password");
	public static final By SignInBtn = By.xpath("//input[@value='Sign In']");
	public static final By UserLogOut = By.xpath("//*[@id=\"myAccountFlyout\"]/ul/li[14]/a");
	public static final By UserName = By.xpath("//span[@class='userT']");
	public static final By NewEmailID = By.id("newEmail");
	public static final By CreateNewAcctPg1 = By.id("newEmailBtn");
	public static final By FirstName = By.id("firstName");
	public static final By LastName = By.id("lastName");
	public static final By NewPswd = By.id("password");
	public static final By NewCnfrmPswd = By.id("cPassword");
	public static final By CreateNewAcctPg2 =  By.id("createAccontBtn");
	public static final By LogOutMyAccount = By.xpath("//*[@id='content']/div[2]/div/ul/li[15]/a");
	public static final By ErrorMsg = By.id("errormessage1");
	public static final By logOutmousehover = By.xpath("//*[@href='/store/account/frags/logOutHeader.jsp']");
		
//Objects related to the PopUps.
	public static final By PopUpWndw1 = By.xpath("//div[@class='lightbox']");
	public static final By PopUpCloseBtn1 = By.xpath("(//span[@class='icon icon-times'])");
	public static final By IBpopclsbtn1 = By.xpath("//*[@id='themeWrapper']/div[10]/div[1]/a");
	public static final By PopUpWndw2 = By.xpath("//*[@class='ui-icon ui-icon-closethick']");
	
//Objects related to the secondary links in the application.
	public static final By Babylink = By.id("ssOurBrands-babySprite");
	public static final By CostPlusWordMarketlink = By.id("ssOurBrands-cpwmSprite");
	public static final By ChristmasTreeShopslink = By.id("ssOurBrands-ctsSprite");
	public static final By HarmanFaceValueslink = By.id("ssOurBrands-harmonSprite");
	public static final By OfAKindlink = By.id("ssOurBrands-oakSprite");
	public static final By OneKingsLanelink = By.id("ssOurBrands-kingsSprite");
	public static final By PersonalizationMalllink = By.id("ssOurBrands-pmallsSprite");	
	public static final By FindAStore = By.linkText("Find A Store");
	public static final By StoreLocator = By.id("storeLocatorOmnibarInput");
	public static final By YouMayLike = By.cssSelector("a[href*='/store/personalstore']");
	public static final By OurRecommendations = By.xpath("//div[@class='grid_12 pspHeader']");
	public static final By SignUpForOffers = By.linkText("Sign Up For Offers");
	public static final By MyOffers = By.className("SSMyOffersLink");
	public static final By TrackOrder = By.xpath("//a[contains(text(),'Track Order')]");
	public static final By OrderTracking = By.xpath("//h1['Order Tracking']");
	public static final By GiftCards = By.linkText("Gift Cards");
	public static final By ContactUS = By.xpath("//a[@href='/store/selfservice/ContactUs']");
	public static final By ContactUsPage = By.xpath("//h1['Contact Us ']");
	public static final By UISisterLinks = By.xpath("//*[@id='ssOurBrands-textLinks']/ul/li/a");
	public static final By TrendsNIdeas = By.xpath("//*[@title='Shop Inspirations']");
	public static final By ShipTo = By.id("shipToLink");
	public static final By SearchItem = By.xpath("//button[@value='submit your search']");
	public static final By InputsearchItem = By.id("searchFormInput");

	//Objects related to the Cart, QuickView & Registry	
	public static final By Cart = By.id("shoppingCartMenu");
	public static final By AddtoCart = By.name("btnAddToCart");
	public static final By CartSummary = By.xpath("//div[@class='addCartModalCheckout']");
	public static final By ViewCart = By.xpath("//a[contains(text(),'VIEW CART')]");
	public static final By KeepShopping = By.xpath("//input[@class='continueShop']");
	public static final By ProductTitleinCart = By.xpath("//*[@class='cartAddedTitle']");
	public static final By QuickView = By.xpath("//*[contains(text(),'Quick View')]");
	public static final By QVProdDesc = By.xpath("//*[@class='prodDescHead noMar']");
	public static final By Quantity = By.xpath("//*[@id='quantity']");
	public static final By AddtoRegistry = By.xpath("//*[@value='Add To Registry']");
	public static final By ProductRegTitle = By.xpath("//*[@class='registryAddedTitle']");
	public static final By Comparefindinstore = By.xpath("//*[contains(text(),'Find In Store')]");
	

	//Objects related to store location
	public static final By ChangeStore = By.xpath("//*[@class='viewStoreDetails']");
	public static final By EnterZip = By.id("searchStoreField");
	public static final By FindStore = By.id("findStores");
	public static final By TCShoppingCenter = By.xpath("//*[contains(text(),'Town & Country Shopping Center')]");
	public static final By TCSCSelectStore = By.xpath("//*[contains(text(),'Town & Country Shopping Center')]/following::input[1]");
	public static final By FindINStore = By.xpath("//*[contains(text(),'Find In Store')]");
	public static final By ReserveNow = By.xpath("//*[@class='reserveNow spCtaBtn']");
	public static final By PorchZipcode = By.name("postalCode");
	
	
	//Objects related to Home Page,IdeaBoard	
	public static final By BBBLink = By.xpath("//*[@id='siteLogo']/a");	
	public static final By Heart = By.id("heartIcon");
	public static final By IBcertona = By.xpath("//*[@class='saveToBoardBtn saveBoardLink STBIcon']");
	public static final By CreateIB = By.xpath("//*[@class='createNewBtn']/a");//this icon is from the home page certona container 
	public static final By IBName = By.id("newBoardName");
	public static final By SaveIB = By.id("saveToIdeaBoardBtn");
	public static final By SaveIBCnfmn = By.className("modalTitle");
	public static final By IBTitle = By.className("//*[@class='icon icon-checkmark block inline']");
	public static final By Return = By.className("ui-button-text");
	public static final By HeroBanner = By.xpath("//*[@id='hero']");
	public static final By UserCreateIB = By.xpath("//a[contains(text(),'Create New Idea Board')]");
	public static final By NewBoardName = By.id("newBoardName");
	public static final By AddtoIdeaBoard = By.xpath("//*[@class='iBNameText']");
	public static final By UserIBMyAccount = By.xpath("//*[@id='content']/div[2]/div/ul/li[7]/a");
	public static final By AddNotes = By.xpath("//*[@class='commentTextArea']");
	public static final By SaveNote = By.xpath("//*[@id='submitCommentBtn']");	
	public static final By PDPIdeaBoard = By.xpath("//a[@title='Save To Idea Board']");
	public static final By EditIBSave = By.xpath("//*[@id='saveNewBoard']");
	
//Objects related to My Account		
	public static final By MyAccountVal = By.xpath("//h1[@class='account fl']");
	public static final By CongratsMsg = By.xpath("//p[contains(text(),'Congratulations! Your account has now been created.')]");
	public static final By MyAcntOptionsList = By.xpath("//*[@id='content']/div[2]/div/ul/li");

	
//Objects related to the Comparison of the products
	public static final By AddAnotherItem = By.xpath("(//*[@title='Add Another Item'])[1]");
	public static final By ThirdItem = By.xpath("(//input[@name='Compare'])[3]");
	public static final By CompareProducts = By.xpath("//a[@class='compare-button']");
	public static final By AddAnotherItmBck = By.xpath("//*[@title='Add Another Item']");
	public static final By RemoveAll = By.id("remove-product");
	public static final By CompareDrawer = By.id("compareDrawer");	
	public static final By Comparechkbx = By.name("Compare");	
	
//Objects related to L1 Category
	public static final By Products = By.xpath("//div[@class='shopLink newNav']");												
	public static final By BabyRegistry = By.id("bridalGiftRegistryAnchor");
	public static final By Search = By.id("searchFormInput");
	public static final By Certona = By.id("certonaJustForYou");
	public static final By PopularCategories = By.id("popularCategory");
	public static final By YouMayLikeCategory = By.id("someFunNewProducts");
	public static final By SocialAnnex = By.id("s22_instagram_upload");
	public static final By FLName = By.id("firstNameReg");
	public static final By GiftRegFirstN = By.id("firstNameReg");
	public static final By GiftRegLastN = By.id("lastNameReg");
	public static final By SearchGRHomePg = By.id("btnFindRegistry");
	public static final By GiftPromoRgsrty = By.className("findARegistryFormForm");
	public static final By ShopbyBrand = By.xpath("//*[@href='/store/page/brands']");
	
		
//Objects related to L2 Category
	public static final By Strollers = By.xpath(".//*[@id='collegeBridalArea']/div[1]/div/ul/li[1]/a");
	public static final By CarSeats = By.linkText("Car Seats");
	public static final By Uploadphotoguide = By.linkText("SELECT THE SOURCE BELOW TO UPLOAD PHOTOS");
	public static final By SocialUpload = By.className("s22-icon_select");
	public static final By UploadWdwClose = By.id("s22InstaPopupCloseBtn");
	public static final By MyIdeaBoard = By.xpath("//*[text()='My Idea Boards']");
	public static final By CreateIdeaBoard = By.xpath("//*[@class='createBoardBtn fr']");
	public static final By Internationalshppng = By.id("intlShippingModal");
	public static final By SelectCountry = By.id("selIntlCountry");
	public static final By SelectCurrency = By.id("selIntlCurrency");
	public static final By Clsmodal = By.xpath("//*[@class='ui-icon ui-icon-closethick']");
	public static final By Bedding = By.xpath("//*[@id='collegeBridalArea']/div[1]/div/ul/li[3]/a");
	//public static final By Dining = By.xpath("//*[@id='collegeBridalArea']/div[1]/div/ul/li[6]/a");
	public static final By Dining = By.xpath("//*[@data-panel='shopLinkPanelCat_10003']");
	public static final By BrandsPage = By.xpath("//dd[@class='clearfix']");
	public static final By ShopOurBrandstitle = By.xpath("//h1[contains(text(),'Shop our Brands')]");
	public static final By Brandfilter = By.xpath("//a[@title='Brand']");
	

//Objects related to L3 Category	
	public static final By L3Header = By.xpath("//*[@id='address_l2_l3_brand']");
	public static final By FrameStrollers = By.xpath("//a[contains(text(),'Frame Strollers')]");
	public static final By InfantCarSeats = By.linkText("Infant Car Seats");
	public static final By TrendsIdeasmerch = By.xpath("//*[@id='collegeBridalArea']/div[2]/div/ul/li[1]/div/div");
	public static final By GiftRegistriesPg = By.xpath("//h1[contains(text(),'find a registry')]");
	public static final By CakesDesserts = By.xpath("//a[contains(text(),'Cake & Dessert Servers')]");
	public static final By ProductTitle = By.xpath("//*[@id='productTitle']/a");
	public static final By TruckDeliveryOption = By.xpath("//span[contains(text(),'Truck Delivery Options :')]");
	public static final By SelectDelOption = By.xpath("//a[@class='selectedIndex']");
	public static final By SelectPorch = By.xpath("//*[@class='serviceAttachWidget-checkbox-input noUniform']");
	public static final By Chooseitemsbelow = By.xpath("//a[@class='lnkCollectionItems smoothScrollTo']");
	
//Objects related to the application for test cases
	
	public static final By ProductName = By.xpath("//div[@class='prodName']/a");
	
	
	
	
}
